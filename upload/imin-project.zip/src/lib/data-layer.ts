/**
 * ============================================================================
 *  ImIn | طبقة البيانات الموحّدة (Supabase الحقيقي + الوضع التجريبي)
 * ============================================================================
 *  كل استعلامات الواجهات تمر من هنا:
 *   - إذا كانت بيانات Supabase مضبوطة في src/lib/supabaseClient.js
 *     → تُنفَّذ على قاعدة البيانات الحقيقية مع Realtime.
 *   - إذا لم تكن مضبوطة بعد → يعمل "الوضع التجريبي" تلقائياً عبر
 *     /api/demo (قاعدة بيانات محلية على السيرفر) مع بث لحظي بالتحديث
 *     الدوري كل 3 ثوانٍ.
 *
 *  النتيجة: النظام يعمل كاملاً فور فتحه — بدون أي إعداد مسبق —
 *  ويتحول لـ Supabase الحقيقي تلقائياً بمجرد إدخال بيانات الاتصال.
 * ============================================================================
 */

import {
  supabase,
  isSupabaseConfigured,
  USERS_TABLE,
  SESSIONS_TABLE,
  ATTENDANCE_TABLE,
  BLOCKED_TABLE,
  WARNINGS_TABLE,
  ID_CARDS_BUCKET,
} from "./supabaseClient";
import type {
  AppUser,
  AttendanceRow,
  ProfessorRosterStats,
  RealtimeStatus,
  SessionRow,
} from "./types";

/** نوع HistoryRow (معرف في history-table) — نعيد تعريفه هنا لتجنب الاستيراد الدائري */
export interface HistoryRowData extends AttendanceRow {
  sessions:
    | {
        created_at: string;
        radius: number;
        users: { full_name: string } | null;
      }
    | null;
}

/* -------------------------------------------------------------------------- */
/*  الوضع التجريبي                                                             */
/* -------------------------------------------------------------------------- */

/** true عندما لا تكون بيانات Supabase مضبوطة بعد */
export function isDemoMode(): boolean {
  return !isSupabaseConfigured();
}

/** استدعاء مسار API التجريبي */
async function demoApi<T>(
  action: string,
  payload: Record<string, unknown> = {}
): Promise<T> {
  let response: Response;
  try {
    response = await fetch("/api/demo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, ...payload }),
    });
  } catch {
    const error = new Error("تعذّر الاتصال بالخادم المحلي.");
    (error as Error & { code?: string }).code = "NETWORK";
    throw error;
  }

  const json = (await response.json().catch(() => null)) as
    | { ok: boolean; data?: T; code?: string; error?: string }
    | null;

  if (!json || !response.ok || json.ok === false) {
    const error = new Error(
      json?.error || "حدث خطأ غير متوقع أثناء الاتصال بالخادم."
    ) as Error & { code?: string };
    error.code = json?.code;
    throw error;
  }

  return json.data as T;
}

/** تحويل صورة Blob إلى Data URL (في الوضع التجريبي تُخزَّن مباشرة) */
function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("تعذّر قراءة صورة البطاقة."));
    reader.readAsDataURL(blob);
  });
}

/* -------------------------------------------------------------------------- */
/*  المصادقة (تسجيل الدخول / إنشاء الحساب)                                     */
/* -------------------------------------------------------------------------- */

/**
 * البحث عن حساب عبر البريد + الرقم الجامعي/الوظيفي.
 * ترجع null إذا لم يوجد الحساب (كلمة "غير مسجل").
 */
export async function findUserByLogin(
  email: string,
  universityId: string
): Promise<AppUser | null> {
  if (isDemoMode()) {
    return demoApi<AppUser | null>("login", {
      email,
      university_id: universityId,
    });
  }

  const { data, error } = await supabase
    .from(USERS_TABLE)
    .select("*")
    .eq("email", email)
    .eq("university_id", universityId)
    .limit(1);

  if (error) throw error;
  return data && data.length > 0 ? (data[0] as AppUser) : null;
}

/** التحقق من أن البريد مسجّل مسبقاً */
export async function emailExists(email: string): Promise<boolean> {
  if (isDemoMode()) {
    return demoApi<boolean>("check-email", { email });
  }

  const { data, error } = await supabase
    .from(USERS_TABLE)
    .select("id")
    .eq("email", email)
    .limit(1);

  if (error) throw error;
  return Boolean(data && data.length > 0);
}

/**
 * رفع صورة البطاقة:
 *  - Supabase  → ترفع إلى Storage وترجع الرابط العام.
 *  - تجريبي    → تُحوَّل إلى Data URL وتُخزَّن مع بيانات المستخدم.
 */
export async function uploadIdCard(
  path: string,
  blob: Blob
): Promise<string> {
  if (isDemoMode()) {
    return blobToDataUrl(blob);
  }

  const { error } = await supabase.storage
    .from(ID_CARDS_BUCKET)
    .upload(path, blob, {
      contentType: blob.type || "image/jpeg",
      upsert: false,
      cacheControl: "3600",
    });
  if (error) throw error;

  const { data } = supabase.storage.from(ID_CARDS_BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

/** إنشاء حساب جديد في جدول users */
export async function insertUser(params: {
  full_name: string;
  email: string;
  university_id: string;
  role: "student" | "professor";
  id_card_url: string | null;
}): Promise<AppUser> {
  if (isDemoMode()) {
    return demoApi<AppUser>("register", params);
  }

  const { data, error } = await supabase
    .from(USERS_TABLE)
    .insert(params)
    .select()
    .single();

  if (error) throw error;
  return data as AppUser;
}

/* -------------------------------------------------------------------------- */
/*  الجلسات (لوحة الدكتور)                                                     */
/* -------------------------------------------------------------------------- */

/** جلب جلسة الدكتور المفتوحة + آخر جلسة منتهية */
export async function fetchProfessorSessions(
  professorId: string
): Promise<{ open: SessionRow | null; lastClosed: SessionRow | null }> {
  if (isDemoMode()) {
    return demoApi<{ open: SessionRow | null; lastClosed: SessionRow | null }>(
      "professor-sessions",
      { professor_id: professorId }
    );
  }

  const { data: openSessions, error: openError } = await supabase
    .from(SESSIONS_TABLE)
    .select("*")
    .eq("professor_id", professorId)
    .eq("is_open", true)
    .order("created_at", { ascending: false })
    .limit(1);
  if (openError) throw openError;

  const { data: closedSessions, error: closedError } = await supabase
    .from(SESSIONS_TABLE)
    .select("*")
    .eq("professor_id", professorId)
    .eq("is_open", false)
    .order("created_at", { ascending: false })
    .limit(1);
  if (closedError) throw closedError;

  return {
    open: (openSessions && openSessions[0]) || null,
    lastClosed: (closedSessions && closedSessions[0]) || null,
  };
}

/** فتح جلسة حضور جديدة (is_open = true) */
export async function createSession(params: {
  professor_id: string;
  lat: number;
  lng: number;
  radius: number;
}): Promise<SessionRow> {
  if (isDemoMode()) {
    return demoApi<SessionRow>("create-session", {
      ...params,
      is_open: true,
    });
  }

  const { data, error } = await supabase
    .from(SESSIONS_TABLE)
    .insert({ ...params, is_open: true })
    .select()
    .single();
  if (error) throw error;
  return data as SessionRow;
}

/** إنهاء الجلسة (is_open = false) */
export async function closeSession(sessionId: string): Promise<void> {
  if (isDemoMode()) {
    await demoApi("close-session", { session_id: sessionId });
    return;
  }

  const { error } = await supabase
    .from(SESSIONS_TABLE)
    .update({ is_open: false })
    .eq("id", sessionId);
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/*  الحضور                                                                     */
/* -------------------------------------------------------------------------- */

/** جلب سجلات حضور جلسة معينة (الأحدث أولاً) */
export async function fetchAttendance(
  sessionId: string
): Promise<AttendanceRow[]> {
  if (isDemoMode()) {
    return demoApi<AttendanceRow[]>("attendance", { session_id: sessionId });
  }

  const { data, error } = await supabase
    .from(ATTENDANCE_TABLE)
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data || []) as AttendanceRow[];
}

/** تسجيل حضور طالب (يرمي 23505 عند التكرار — في الوضعين) */
export async function insertAttendance(params: {
  session_id: string;
  student_id: string;
  student_name: string;
  university_id: string;
}): Promise<void> {
  if (isDemoMode()) {
    await demoApi("check-in", params);
    return;
  }

  const { error } = await supabase.from(ATTENDANCE_TABLE).insert(params);
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/*  الحظر والإنذارات وإحصائيات الطلاب (لوحة الدكتور)                            */
/* -------------------------------------------------------------------------- */

/** جلب جلسة بالمعرف (للتحقق منها قبل تسجيل الحضور) */
export async function fetchSessionById(
  sessionId: string
): Promise<SessionRow | null> {
  if (isDemoMode()) {
    return demoApi<SessionRow | null>("get-session", { session_id: sessionId });
  }

  const { data, error } = await supabase
    .from(SESSIONS_TABLE)
    .select("*")
    .eq("id", sessionId)
    .limit(1);
  if (error) throw error;
  return (data && data[0]) || null;
}

/** جلب ملفات الطلاب (الإيميل الجامعي + صورة البطاقة) عبر معرفاتهم */
export async function fetchStudentProfiles(
  studentIds: string[]
): Promise<AppUser[]> {
  if (studentIds.length === 0) return [];

  if (isDemoMode()) {
    return demoApi<AppUser[]>("student-profiles", { student_ids: studentIds });
  }

  const { data, error } = await supabase
    .from(USERS_TABLE)
    .select("*")
    .in("id", studentIds);
  if (error) throw error;
  return (data || []) as AppUser[];
}

/**
 * جلب إحصائيات حضور الطلاب لدى دكتور معين:
 * عدد الحضور / الغياب / الإنذارات / قائمة المحظورين.
 */
export async function fetchProfessorStats(
  professorId: string
): Promise<ProfessorRosterStats> {
  if (isDemoMode()) {
    return demoApi<ProfessorRosterStats>("professor-stats", {
      professor_id: professorId,
    });
  }

  // جلسات الدكتور (المعرف + حالة الفتح)
  const { data: sessions, error: sessionsError } = await supabase
    .from(SESSIONS_TABLE)
    .select("id,is_open")
    .eq("professor_id", professorId);
  if (sessionsError) throw sessionsError;

  const sessionList = (sessions || []) as { id: string; is_open: boolean }[];
  const sessionIds = sessionList.map((row) => row.id);
  const closedIds = new Set(
    sessionList.filter((row) => !row.is_open).map((row) => row.id)
  );

  // سجلات حضور تلك الجلسات
  let attRows: { student_id: string; session_id: string }[] = [];
  if (sessionIds.length > 0) {
    const { data: rows, error: attError } = await supabase
      .from(ATTENDANCE_TABLE)
      .select("student_id,session_id")
      .in("session_id", sessionIds);
    if (attError) throw attError;
    attRows = (rows || []) as { student_id: string; session_id: string }[];
  }

  const attendedByStudent: Record<string, number> = {};
  const closedAttendedByStudent: Record<string, number> = {};
  for (const row of attRows) {
    attendedByStudent[row.student_id] =
      (attendedByStudent[row.student_id] ?? 0) + 1;
    if (closedIds.has(row.session_id)) {
      closedAttendedByStudent[row.student_id] =
        (closedAttendedByStudent[row.student_id] ?? 0) + 1;
    }
  }

  // الإنذارات (تُهمل بلطف إذا كان المخطط القديم بدون الجدولين الجديدين)
  const warningsByStudent: Record<string, number> = {};
  try {
    const { data: warnings, error: warningsError } = await supabase
      .from(WARNINGS_TABLE)
      .select("student_id")
      .eq("professor_id", professorId);
    if (warningsError) throw warningsError;
    for (const row of (warnings || []) as { student_id: string }[]) {
      warningsByStudent[row.student_id] =
        (warningsByStudent[row.student_id] ?? 0) + 1;
    }
  } catch (error) {
    if ((error as Error & { code?: string }).code !== "42P01") throw error;
  }

  let blockedIds: string[] = [];
  try {
    const { data: blocked, error: blockedError } = await supabase
      .from(BLOCKED_TABLE)
      .select("student_id")
      .eq("professor_id", professorId);
    if (blockedError) throw blockedError;
    blockedIds = ((blocked || []) as { student_id: string }[]).map(
      (row) => row.student_id
    );
  } catch (error) {
    if ((error as Error & { code?: string }).code !== "42P01") throw error;
  }

  return {
    totalSessions: sessionList.length,
    totalClosedSessions: closedIds.size,
    attendedByStudent,
    closedAttendedByStudent,
    warningsByStudent,
    blockedIds,
  };
}

/** حظر طالب (فصله من المادة) — لن يستطيع تسجيل الحضور في جلسات هذا الدكتور */
export async function blockStudent(
  professorId: string,
  studentId: string
): Promise<void> {
  if (isDemoMode()) {
    await demoApi("block-student", {
      professor_id: professorId,
      student_id: studentId,
    });
    return;
  }

  const { error } = await supabase.from(BLOCKED_TABLE).upsert(
    { professor_id: professorId, student_id: studentId },
    { onConflict: "professor_id,student_id" }
  );
  if (error) throw error;
}

/** فك الحظر عن طالب */
export async function unblockStudent(
  professorId: string,
  studentId: string
): Promise<void> {
  if (isDemoMode()) {
    await demoApi("unblock-student", {
      professor_id: professorId,
      student_id: studentId,
    });
    return;
  }

  const { error } = await supabase
    .from(BLOCKED_TABLE)
    .delete()
    .eq("professor_id", professorId)
    .eq("student_id", studentId);
  if (error) throw error;
}

/** تسجيل إنذار على طالب */
export async function warnStudent(
  professorId: string,
  studentId: string,
  reason?: string
): Promise<void> {
  if (isDemoMode()) {
    await demoApi("warn-student", {
      professor_id: professorId,
      student_id: studentId,
      reason: reason ?? null,
    });
    return;
  }

  const { error } = await supabase
    .from(WARNINGS_TABLE)
    .insert({ professor_id: professorId, student_id: studentId, reason: reason ?? null });
  if (error) throw error;
}

/** هل الطالب محظور لدى هذا الدكتور؟ */
export async function isStudentBlocked(
  professorId: string,
  studentId: string
): Promise<boolean> {
  if (isDemoMode()) {
    return demoApi<boolean>("is-blocked", {
      professor_id: professorId,
      student_id: studentId,
    });
  }

  try {
    const { data, error } = await supabase
      .from(BLOCKED_TABLE)
      .select("id")
      .eq("professor_id", professorId)
      .eq("student_id", studentId)
      .limit(1);
    if (error) throw error;
    return Boolean(data && data.length > 0);
  } catch (error) {
    if ((error as Error & { code?: string }).code === "42P01") return false;
    throw error;
  }
}

/* -------------------------------------------------------------------------- */
/*  الجلسات المفتوحة (لوحة الطالب)                                             */
/* -------------------------------------------------------------------------- */

/** الجلسات المفتوحة حالياً مع اسم الدكتور (عبر users(full_name)) */
export async function fetchOpenSessions(): Promise<SessionRow[]> {
  if (isDemoMode()) {
    return demoApi<SessionRow[]>("open-sessions");
  }

  const { data, error } = await supabase
    .from(SESSIONS_TABLE)
    .select("*, users(full_name)")
    .eq("is_open", true)
    .order("created_at", { ascending: false })
    .limit(10);
  if (error) throw error;
  return (data || []) as unknown as SessionRow[];
}

/** الجلسات (من قائمة معينة) التي سجّل الطالب حضوره فيها بالفعل */
export async function fetchAttendedSessionIds(
  studentId: string,
  sessionIds: string[]
): Promise<string[]> {
  if (sessionIds.length === 0) return [];

  if (isDemoMode()) {
    return demoApi<string[]>("attended-ids", {
      student_id: studentId,
      session_ids: sessionIds,
    });
  }

  const { data, error } = await supabase
    .from(ATTENDANCE_TABLE)
    .select("session_id")
    .eq("student_id", studentId)
    .in("session_id", sessionIds);
  if (error) throw error;
  return ((data || []) as { session_id: string }[]).map((row) => row.session_id);
}

/** سجل حضور الطالب مع تفاصيل الجلسة والدكتور (sessions -> users) */
export async function fetchStudentHistory(
  studentId: string
): Promise<HistoryRowData[]> {
  if (isDemoMode()) {
    return demoApi<HistoryRowData[]>("history", { student_id: studentId });
  }

  const { data, error } = await supabase
    .from(ATTENDANCE_TABLE)
    .select(
      "id, session_id, student_id, student_name, university_id, created_at, sessions(created_at, radius, users(full_name))"
    )
    .eq("student_id", studentId)
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data || []) as unknown as HistoryRowData[];
}

/* -------------------------------------------------------------------------- */
/*  الاشتراك اللحظي (Realtime)                                                 */
/* -------------------------------------------------------------------------- */

/**
 * اشتراك الدكتور في حضور جلسته:
 *  - Supabase : postgres_changes على INSERT في جدول attendance.
 *  - تجريبي   : تحديث دوري كل 3 ثوانٍ يستبدل القائمة كاملة.
 * ترجع دالة إلغاء الاشتراك.
 */
export function subscribeAttendanceUpdates(
  sessionId: string,
  handlers: {
    /** الوضع التجريبي: استبدال القائمة كاملة */
    onRows: (rows: AttendanceRow[]) => void;
    /** Supabase Realtime: إلحاق صف جديد */
    onAppend: (row: AttendanceRow) => void;
    onStatus: (status: RealtimeStatus) => void;
  }
): () => void {
  if (isDemoMode()) {
    let stopped = false;
    handlers.onStatus("live");

    const poll = async () => {
      if (stopped || typeof document === "undefined") return;
      if (document.visibilityState === "hidden") return;
      try {
        const rows = await fetchAttendance(sessionId);
        if (!stopped) handlers.onRows(rows);
      } catch {
        /* تجاهل أخطاء الاستقصاء الفردي */
      }
    };

    void poll();
    const intervalId = window.setInterval(poll, 3000);
    return () => {
      stopped = true;
      window.clearInterval(intervalId);
    };
  }

  handlers.onStatus("connecting");

  const channel = supabase
    .channel(`professor-attendance-${sessionId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: ATTENDANCE_TABLE,
        filter: `session_id=eq.${sessionId}`,
      },
      (payload) => {
        handlers.onAppend(payload.new as AttendanceRow);
      }
    )
    .subscribe((status) => {
      if (status === "SUBSCRIBED") handlers.onStatus("live");
      else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT")
        handlers.onStatus("error");
      else handlers.onStatus("connecting");
    });

  return () => {
    supabase.removeChannel(channel);
  };
}

/**
 * اشتراك الطالب في تغيّرات الجلسات (فتح/إنهاء):
 *  - Supabase : postgres_changes على INSERT/UPDATE في جدول sessions.
 *  - تجريبي   : تحديث دوري كل 3 ثوانٍ.
 * ترجع دالة إلغاء الاشتراك.
 */
export function subscribeSessionUpdates(onChange: () => void): () => void {
  if (isDemoMode()) {
    let stopped = false;
    const tick = () => {
      if (stopped) return;
      if (typeof document !== "undefined" && document.visibilityState === "hidden")
        return;
      onChange();
    };
    const intervalId = window.setInterval(tick, 3000);
    return () => {
      stopped = true;
      window.clearInterval(intervalId);
    };
  }

  const channel = supabase
    .channel("student-sessions-live")
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: SESSIONS_TABLE },
      () => onChange()
    )
    .on(
      "postgres_changes",
      { event: "UPDATE", schema: "public", table: SESSIONS_TABLE },
      () => onChange()
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
