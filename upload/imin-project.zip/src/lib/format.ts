/**
 * ImIn | دوال تنسيق الأرقام والتواريخ بالعربية (أرقام لاتينية للوضوح التقني)
 */

const AR_LOCALE = "ar-EG-u-nu-latn";

/** الوقت بصيغة HH:MM (مثال: 09:45 صباحاً) */
export function formatTime(isoDate: string): string {
  return new Date(isoDate).toLocaleTimeString(AR_LOCALE, {
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** التاريخ بصيغة عربية (مثال: الأحد، 5 أكتوبر 2026) */
export function formatDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString(AR_LOCALE, {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/** التاريخ والوقت معاً */
export function formatDateTime(isoDate: string): string {
  return `${formatDate(isoDate)} — ${formatTime(isoDate)}`;
}

/** تاريخ مختصر (مثال: 5 أكتوبر) */
export function formatShortDate(isoDate: string): string {
  return new Date(isoDate).toLocaleDateString(AR_LOCALE, {
    day: "numeric",
    month: "long",
  });
}

/** الوقت المنقضي بصيغة نسبية (مثال: منذ 5 دقائق) */
export function relativeTime(isoDate: string, now: number = Date.now()): string {
  const diffSeconds = Math.max(0, Math.floor((now - new Date(isoDate).getTime()) / 1000));
  if (diffSeconds < 30) return "قبل لحظات";
  if (diffSeconds < 60) return `منذ ${diffSeconds} ثانية`;
  const minutes = Math.floor(diffSeconds / 60);
  if (minutes < 60) return `منذ ${minutes} ${minutes === 1 ? "دقيقة" : minutes === 2 ? "دقيقتين" : "دقائق"}`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `منذ ${hours} ${hours === 1 ? "ساعة" : hours === 2 ? "ساعتين" : "ساعات"}`;
  const days = Math.floor(hours / 24);
  return `منذ ${days} ${days === 1 ? "يوم" : "أيام"}`;
}

/** عدّاد مدة الجلسة بصيغة رقمية (mm:ss أو h:mm:ss) */
export function formatDurationClock(milliseconds: number): string {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const padded = (value: number) => String(value).padStart(2, "0");
  return hours > 0
    ? `${hours}:${padded(minutes)}:${padded(seconds)}`
    : `${padded(minutes)}:${padded(seconds)}`;
}

/** تنسيق المسافة (مثال: 34 م — 1.24 كم) */
export function formatDistance(meters: number): string {
  if (meters >= 1000) return `${(meters / 1000).toFixed(2)} كم`;
  if (meters < 10) return `${meters.toFixed(1)} م`;
  return `${Math.round(meters)} م`;
}

/** تحية حسب الوقت الحالي */
export function greetingForNow(date: Date = new Date()): string {
  const hour = date.getHours();
  if (hour < 12) return "صباح الخير";
  if (hour < 17) return "طاب يومك";
  return "مساء الخير";
}
