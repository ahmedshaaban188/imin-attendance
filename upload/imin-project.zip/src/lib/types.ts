/**
 * ImIn | الأنواع المشتركة المستخدمة في كل واجهات النظام
 * (مطابقة تماماً لمخطط قاعدة بيانات Supabase في supabase/schema.sql)
 */

export type UserRole = "student" | "professor";

/** صف من جدول users */
export interface AppUser {
  id: string;
  full_name: string;
  email: string;
  university_id: string;
  role: UserRole;
  id_card_url: string | null;
  created_at: string;
}

/** صف من جدول sessions مع اسم الدكتور (عبر علاقة users) */
export interface SessionRow {
  id: string;
  professor_id: string;
  lat: number | string;
  lng: number | string;
  radius: number;
  is_open: boolean;
  created_at: string;
  /** يأتي من الاستعلام المتداخل: sessions -> users(full_name) */
  users?: { full_name: string } | null;
}

/** صف من جدول attendance */
export interface AttendanceRow {
  id: string;
  session_id: string;
  student_id: string;
  student_name: string;
  university_id: string;
  created_at: string;
}

/** حالة الاشتراك اللحظي (Realtime) */
export type RealtimeStatus = "connecting" | "live" | "error" | "closed";

/** إحصائيات حضور الطلاب لدى دكتور معين (تُعرض في لوحة الدكتور) */
export interface ProfessorRosterStats {
  /** إجمالي جلسات الدكتور */
  totalSessions: number;
  /** الجلسات المنتهية فقط (الجلسة الجارية لا تُحسب غياباً) */
  totalClosedSessions: number;
  /** عدد مرات الحضور لكل طالب (يشمل الجلسة الجارية) */
  attendedByStudent: Record<string, number>;
  /** عدد مرات الحضور في الجلسات المنتهية فقط (لحساب الغياب) */
  closedAttendedByStudent: Record<string, number>;
  /** عدد الإنذارات لكل طالب */
  warningsByStudent: Record<string, number>;
  /** معرفات الطلاب المحظورين (المفصولين من المادة) */
  blockedIds: string[];
}

/** موضع GPS الحالي */
export interface GeoPosition {
  lat: number;
  lng: number;
  /** دقة التحديد بالأمتار (±) */
  accuracy: number;
}
