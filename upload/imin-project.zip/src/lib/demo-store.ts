/**
 * ============================================================================
 *  ImIn | قاعدة البيانات التجريبية (وضع Demo بدون Supabase)
 * ============================================================================
 *  تعمل هذه الوحدة على السيرفر فقط (تُستخدم من /api/demo) وتوفّر نفس سلوك
 *  جداول Supabase الثلاثة (users / sessions / attendance) لكن فوق ملف JSON
 *  محلي يُحفظ في data/imin-demo.json — ليعمل النظام كاملاً فوراً قبل ربط
 *  Supabase الحقيقي.
 *
 *  ملاحظات:
 *  - بمجرد وضع بيانات Supabase الحقيقية في src/lib/supabaseClient.js
 *    يتحول النظام تلقائياً إلى قاعدة البيانات الحقيقية ويتجاهل هذا الملف.
 *  - هذا الملف غير مخصص للاستخدام الإنتاجي — إنه للاستكشاف والتجربة فقط.
 * ============================================================================
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import path from "path";
import { randomUUID } from "crypto";

/* -------------------------------------------------------------------------- */
/*  الأنواع (مطابقة تماماً لمخطط supabase/schema.sql)                          */
/* -------------------------------------------------------------------------- */

interface DemoUser {
  id: string;
  full_name: string;
  email: string;
  university_id: string;
  role: "student" | "professor";
  id_card_url: string | null;
  created_at: string;
}

interface DemoSession {
  id: string;
  professor_id: string;
  lat: number;
  lng: number;
  radius: number;
  is_open: boolean;
  created_at: string;
}

interface DemoAttendance {
  id: string;
  session_id: string;
  student_id: string;
  student_name: string;
  university_id: string;
  created_at: string;
}

/** طالب محظور (مفصول) من محاضرات دكتور معين — لا يستطيع تسجيل الحضور */
interface DemoBlocked {
  id: string;
  professor_id: string;
  student_id: string;
  created_at: string;
}

/** إنذار مسجّل من دكتور على طالب */
interface DemoWarning {
  id: string;
  professor_id: string;
  student_id: string;
  reason: string | null;
  created_at: string;
}

interface DemoDb {
  users: DemoUser[];
  sessions: DemoSession[];
  attendance: DemoAttendance[];
  blocked: DemoBlocked[];
  warnings: DemoWarning[];
}

/* -------------------------------------------------------------------------- */
/*  التحميل والحفظ (ملف JSON يبقى بعد إعادة تشغيل سيرفر التطوير)               */
/* -------------------------------------------------------------------------- */

const DATA_DIR = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "imin-demo.json");
/* v2 — إعادة تحميل الوحدة تقرأ الملف من جديد (لإفراغ بيانات الاختبار) — v5 */

function loadDb(): DemoDb {
  try {
    if (!existsSync(DATA_FILE)) {
      return { users: [], sessions: [], attendance: [], blocked: [], warnings: [] };
    }
    const parsed = JSON.parse(readFileSync(DATA_FILE, "utf8"));
    return {
      users: Array.isArray(parsed?.users) ? parsed.users : [],
      sessions: Array.isArray(parsed?.sessions) ? parsed.sessions : [],
      attendance: Array.isArray(parsed?.attendance) ? parsed.attendance : [],
      blocked: Array.isArray(parsed?.blocked) ? parsed.blocked : [],
      warnings: Array.isArray(parsed?.warnings) ? parsed.warnings : [],
    };
  } catch {
    return { users: [], sessions: [], attendance: [], blocked: [], warnings: [] };
  }
}

const db: DemoDb = loadDb();

function saveDb() {
  try {
    if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(DATA_FILE, JSON.stringify(db, null, 2), "utf8");
  } catch (error) {
    console.warn("ImIn demo store: تعذر حفظ ملف البيانات التجريبية", error);
  }
}

/* -------------------------------------------------------------------------- */
/*  أدوات مساعدة                                                              */
/* -------------------------------------------------------------------------- */

/** خطأ نطاقي يحمل رمزاً (مثل 23505 للتكرار) كما تفعل أخطاء Postgres/Supabase */
function fail(message: string, code?: string): never {
  const error = new Error(message) as Error & { code?: string };
  if (code) error.code = code;
  throw error;
}

function asText(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function byNewest<T extends { created_at: string }>(a: T, b: T): number {
  return b.created_at.localeCompare(a.created_at);
}

/** ربط الجلسة باسم الدكتور (مكافئ العلاقة المتداخلة users(full_name)) */
function sessionWithProfessor(session: DemoSession) {
  const professor = db.users.find((user) => user.id === session.professor_id);
  return {
    ...session,
    users: { full_name: professor?.full_name ?? null },
  };
}

/* -------------------------------------------------------------------------- */
/*  تنفيذ الإجراءات (مكافئة تماماً لاستعلامات Supabase في الواجهات)             */
/* -------------------------------------------------------------------------- */

export async function demoAction(
  action: string,
  payload: Record<string, unknown>
): Promise<unknown> {
  switch (action) {
    /* ------------------------------ المصادقة ------------------------------ */

    case "login": {
      const email = asText(payload.email).toLowerCase();
      const universityId = asText(payload.university_id);
      const user = db.users.find(
        (row) => row.email === email && row.university_id === universityId
      );
      return user ?? null;
    }

    case "check-email": {
      const email = asText(payload.email).toLowerCase();
      return db.users.some((row) => row.email === email);
    }

    case "register": {
      const email = asText(payload.email).toLowerCase();
      if (db.users.some((row) => row.email === email)) {
        fail("هذا البريد الإلكتروني مسجّل مسبقاً.", "EMAIL_EXISTS");
      }
      const user: DemoUser = {
        id: randomUUID(),
        full_name: asText(payload.full_name),
        email,
        university_id: asText(payload.university_id),
        role: payload.role === "professor" ? "professor" : "student",
        id_card_url:
          typeof payload.id_card_url === "string" ? payload.id_card_url : null,
        created_at: new Date().toISOString(),
      };
      db.users.push(user);
      saveDb();
      return user;
    }

    /* ------------------------------ الجلسات ------------------------------ */

    case "professor-sessions": {
      const professorId = asText(payload.professor_id);
      const mine = db.sessions.filter(
        (session) => session.professor_id === professorId
      );
      const open = mine.filter((session) => session.is_open).sort(byNewest)[0] ?? null;
      const lastClosed =
        mine.filter((session) => !session.is_open).sort(byNewest)[0] ?? null;
      return { open, lastClosed };
    }

    case "create-session": {
      const session: DemoSession = {
        id: randomUUID(),
        professor_id: asText(payload.professor_id),
        lat: Number(payload.lat),
        lng: Number(payload.lng),
        radius: Math.max(20, Math.round(Number(payload.radius)) || 50),
        is_open: true,
        created_at: new Date().toISOString(),
      };
      db.sessions.push(session);
      saveDb();
      return session;
    }

    case "close-session": {
      const sessionId = asText(payload.session_id);
      const session = db.sessions.find((row) => row.id === sessionId);
      if (!session) fail("الجلسة غير موجودة.", "SESSION_NOT_FOUND");
      session.is_open = false;
      saveDb();
      return { ok: true };
    }

    case "open-sessions": {
      return db.sessions
        .filter((session) => session.is_open)
        .sort(byNewest)
        .slice(0, 10)
        .map(sessionWithProfessor);
    }

    /* ------------------------------ الحضور ------------------------------- */

    case "attendance": {
      const sessionId = asText(payload.session_id);
      return db.attendance
        .filter((row) => row.session_id === sessionId)
        .sort(byNewest);
    }

    case "attended-ids": {
      const studentId = asText(payload.student_id);
      const sessionIds = Array.isArray(payload.session_ids)
        ? (payload.session_ids as unknown[])
        : [];
      if (sessionIds.length === 0 || !studentId) return [];
      return db.attendance
        .filter(
          (row) =>
            row.student_id === studentId && sessionIds.includes(row.session_id)
        )
        .map((row) => row.session_id);
    }

    case "history": {
      const studentId = asText(payload.student_id);
      return db.attendance
        .filter((row) => row.student_id === studentId)
        .sort(byNewest)
        .slice(0, 50)
        .map((row) => {
          const session = db.sessions.find((s) => s.id === row.session_id);
          return {
            ...row,
            sessions: session
              ? {
                  created_at: session.created_at,
                  radius: session.radius,
                  users: {
                    full_name:
                      db.users.find((user) => user.id === session.professor_id)
                        ?.full_name ?? null,
                  },
                }
              : null,
          };
        });
    }

    case "check-in": {
      const sessionId = asText(payload.session_id);
      const studentId = asText(payload.student_id);

      const session = db.sessions.find((row) => row.id === sessionId);
      if (!session || !session.is_open) {
        fail("هذه الجلسة غير مفتوحة — لا يمكن تسجيل الحضور.", "SESSION_CLOSED");
      }

      // طالب محظور من هذا الدكتور؟ (مكافئ تريجر imin_block_check في Postgres)
      const isBlocked = db.blocked.some(
        (row) =>
          row.professor_id === session.professor_id && row.student_id === studentId
      );
      if (isBlocked) {
        fail("أنت محظور من حضور محاضرات هذا الدكتور.", "BLOCKED");
      }

      // القيد الفريد session_id + student_id (مكافئ 23505 في Postgres)
      const duplicate = db.attendance.some(
        (row) => row.session_id === sessionId && row.student_id === studentId
      );
      if (duplicate) {
        fail("حضور مكرر في نفس الجلسة.", "23505");
      }

      const record: DemoAttendance = {
        id: randomUUID(),
        session_id: sessionId,
        student_id: studentId,
        student_name: asText(payload.student_name),
        university_id: asText(payload.university_id),
        created_at: new Date().toISOString(),
      };
      db.attendance.push(record);
      saveDb();
      return record;
    }

    /* --------------------------- الحظر والإنذارات --------------------------- */

    case "get-session": {
      const session = db.sessions.find(
        (row) => row.id === asText(payload.session_id)
      );
      return session ? { ...session, users: null } : null;
    }

    case "student-profiles": {
      const ids = Array.isArray(payload.student_ids)
        ? (payload.student_ids as unknown[]).map((id) => asText(id))
        : [];
      if (ids.length === 0) return [];
      return db.users.filter((user) => ids.includes(user.id));
    }

    case "professor-stats": {
      const professorId = asText(payload.professor_id);
      const mySessions = db.sessions.filter(
        (session) => session.professor_id === professorId
      );
      const closedIds = new Set(
        mySessions.filter((session) => !session.is_open).map((session) => session.id)
      );
      const mySessionIds = new Set(mySessions.map((session) => session.id));

      const attendedByStudent: Record<string, number> = {};
      const closedAttendedByStudent: Record<string, number> = {};
      for (const row of db.attendance) {
        if (!mySessionIds.has(row.session_id)) continue;
        attendedByStudent[row.student_id] =
          (attendedByStudent[row.student_id] ?? 0) + 1;
        if (closedIds.has(row.session_id)) {
          closedAttendedByStudent[row.student_id] =
            (closedAttendedByStudent[row.student_id] ?? 0) + 1;
        }
      }

      const warningsByStudent: Record<string, number> = {};
      for (const warning of db.warnings) {
        if (warning.professor_id !== professorId) continue;
        warningsByStudent[warning.student_id] =
          (warningsByStudent[warning.student_id] ?? 0) + 1;
      }

      return {
        totalSessions: mySessions.length,
        totalClosedSessions: closedIds.size,
        attendedByStudent,
        closedAttendedByStudent,
        warningsByStudent,
        blockedIds: db.blocked
          .filter((row) => row.professor_id === professorId)
          .map((row) => row.student_id),
      };
    }

    case "block-student": {
      const professorId = asText(payload.professor_id);
      const studentId = asText(payload.student_id);
      if (!professorId || !studentId) {
        fail("بيانات الحظر غير مكتملة.", "BAD_REQUEST");
      }
      const exists = db.blocked.some(
        (row) => row.professor_id === professorId && row.student_id === studentId
      );
      if (!exists) {
        db.blocked.push({
          id: randomUUID(),
          professor_id: professorId,
          student_id: studentId,
          created_at: new Date().toISOString(),
        });
        saveDb();
      }
      return { ok: true };
    }

    case "unblock-student": {
      const professorId = asText(payload.professor_id);
      const studentId = asText(payload.student_id);
      db.blocked = db.blocked.filter(
        (row) => !(row.professor_id === professorId && row.student_id === studentId)
      );
      saveDb();
      return { ok: true };
    }

    case "warn-student": {
      const professorId = asText(payload.professor_id);
      const studentId = asText(payload.student_id);
      if (!professorId || !studentId) {
        fail("بيانات الإنذار غير مكتملة.", "BAD_REQUEST");
      }
      db.warnings.push({
        id: randomUUID(),
        professor_id: professorId,
        student_id: studentId,
        reason: typeof payload.reason === "string" ? asText(payload.reason) : null,
        created_at: new Date().toISOString(),
      });
      saveDb();
      return { ok: true };
    }

    case "is-blocked": {
      const professorId = asText(payload.professor_id);
      const studentId = asText(payload.student_id);
      return db.blocked.some(
        (row) => row.professor_id === professorId && row.student_id === studentId
      );
    }

    default:
      fail(`إجراء غير معروف: ${action}`, "UNKNOWN_ACTION");
  }
}
