/**
 * ImIn | شعار النظام — دبوس موقع بداخله علامة صح (I'm IN = أنا حاضر)
 */

export function LogoMark({ size = 40 }: { size?: number }) {
  return (
    <span
      className="inline-flex items-center justify-center rounded-2xl btn-gradient no-select shrink-0"
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <svg
        width={size * 0.58}
        height={size * 0.58}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2.4}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z" fill="rgba(255,255,255,0.16)" />
        <path d="m8.5 11.2 2.4 2.4 4.6-4.9" />
      </svg>
    </span>
  );
}

export function Logo({
  size = 40,
  withWordmark = true,
  tagline,
}: {
  size?: number;
  withWordmark?: boolean;
  tagline?: string;
}) {
  return (
    <span className="inline-flex items-center gap-3 no-select">
      <LogoMark size={size} />
      {withWordmark && (
        <span className="flex flex-col leading-tight">
          <span className="text-2xl font-black tracking-tight text-foreground">
            Im<span className="text-gradient">In</span>
          </span>
          {tagline && (
            <span className="text-[11px] font-semibold text-muted-foreground">{tagline}</span>
          )}
        </span>
      )}
    </span>
  );
}
