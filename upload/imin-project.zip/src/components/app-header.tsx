"use client";

/**
 * ImIn | الشريط العلوي الزجاجي للوحات التحكم (الدكتور / الطالب)
 */

import { LogOut } from "lucide-react";
import { Logo } from "@/components/logo";
import { ThemeToggle } from "@/components/theme-toggle";
import type { AppUser } from "@/lib/types";
import type { ReactNode } from "react";

export function AppHeader({
  user,
  badge,
  onLogout,
  extra,
}: {
  user: AppUser;
  badge: string;
  onLogout: () => void;
  /** عنصر إضافي اختياري بجانب شارة اللوحة (مثل شارة الوضع التجريبي) */
  extra?: ReactNode;
}) {
  const initials = user.full_name
    .split(" ")
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("");

  return (
    <header className="sticky top-0 z-40 px-3 pt-3 sm:px-4">
      <div className="glass-nav mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 rounded-2xl px-3 sm:px-5">
        <div className="flex min-w-0 items-center gap-3">
          <Logo size={38} />
          <span
            className="hidden rounded-full bg-primary/12 px-3.5 py-1.5 text-xs font-extrabold text-primary sm:inline-block"
            title={badge}
          >
            {badge}
          </span>
          {extra}
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* بطاقة المستخدم */}
          <div className="glass-chip flex items-center gap-2.5 rounded-full py-1 pe-3 ps-1">
            {user.id_card_url ? (
               
              <img
                src={user.id_card_url}
                alt={`صورة بطاقة ${user.full_name}`}
                className="h-9 w-9 rounded-full object-cover ring-2 ring-primary/30"
              />
            ) : (
              <span className="grid h-9 w-9 place-items-center rounded-full bg-primary/15 text-sm font-black text-primary ring-2 ring-primary/20">
                {initials}
              </span>
            )}
            <span className="hidden flex-col leading-tight md:flex">
              <span className="max-w-36 truncate text-sm font-extrabold">{user.full_name}</span>
              <span className="text-[11px] text-muted-foreground" dir="ltr">
                {user.university_id}
              </span>
            </span>
          </div>

          <ThemeToggle />

          <button
            type="button"
            onClick={onLogout}
            aria-label="تسجيل الخروج"
            title="تسجيل الخروج"
            className="glass-chip inline-flex h-11 w-11 items-center justify-center rounded-full text-foreground/70 transition-all hover:scale-105 hover:text-destructive active:scale-95"
          >
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
