"use client";

/**
 * ImIn | مزوّدو الواجهة من جهة العميل
 * - ThemeProvider: إدارة الوضع الفاتح/الداكن (next-themes) بتبديل سلس
 * - Toaster: تنبيهات Sonner موجّهة من اليمين لليسار (RTL)
 */

import { ThemeProvider as NextThemesProvider } from "next-themes";
import { Toaster } from "@/components/ui/sonner";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="system"
      enableColorScheme
      disableTransitionOnChange={false}
    >
      {children}
      <Toaster dir="rtl" position="top-center" richColors closeButton />
    </NextThemesProvider>
  );
}
