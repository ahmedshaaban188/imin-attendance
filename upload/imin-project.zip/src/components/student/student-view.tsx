"use client";

/**
 * ============================================================================
 *  ImIn | لوحة تحكم الطالب (مكافئ student-dashboard.html)
 * ============================================================================
 *  - بيانات الطالب الحالية (الاسم، الرقم الجامعي، صورة الهوية) من جدول users
 *    المحفوظة في localStorage في الهيدر
 *  - كشف الجلسات المفتوحة لحظياً (Realtime على جدول sessions + تحديث دوري)
 *  - تسجيل الحضور في جدول attendance عند الضغط داخل النطاق
 *  - سجل حضور المواد السابقة في جدول منسّق
 * ============================================================================
 */

import * as React from "react";
import { toast } from "sonner";
import { AppHeader } from "@/components/app-header";
import { DemoBadge } from "@/components/demo-badge";
import { DigitalIdCard } from "@/components/student/digital-id-card";
import { SessionPanel } from "@/components/student/session-panel";
import { HistoryTable, type HistoryRow } from "@/components/student/history-table";
import {
  fetchOpenSessions,
  fetchAttendedSessionIds,
  fetchStudentHistory,
  fetchSessionById,
  insertAttendance,
  isStudentBlocked,
  subscribeSessionUpdates,
} from "@/lib/data-layer";
import { friendlyError } from "@/lib/supabaseClient";
import { formatDate, greetingForNow } from "@/lib/format";
import type { AppUser, SessionRow } from "@/lib/types";

export function StudentView({
  user,
  onLogout,
}: {
  user: AppUser;
  onLogout: () => void;
}) {
  const [openSessions, setOpenSessions] = React.useState<SessionRow[]>([]);
  const [loadingSessions, setLoadingSessions] = React.useState(true);
  const [attendedIds, setAttendedIds] = React.useState<string[]>([]);
  const [history, setHistory] = React.useState<HistoryRow[]>([]);
  const [loadingHistory, setLoadingHistory] = React.useState(true);
  const [checkingIn, setCheckingIn] = React.useState(false);
  const [justCheckedInSessionId, setJustCheckedInSessionId] = React.useState<string | null>(null);

  /** الجلسات المعروفة سابقاً — لاكتشاف الجلسات المفتوحة حديثاً وإشعار الطالب */
  const knownSessionIdsRef = React.useRef<Set<string> | null>(null);

  /* ------------------------------------------------------------------ */
  /*  جلب الجلسات المفتوحة + الجلسات التي حضرها الطالب بالفعل              */
  /* ------------------------------------------------------------------ */
  const refreshOpenSessions = React.useCallback(async () => {
    try {
      const sessions = await fetchOpenSessions();
      setOpenSessions(sessions);

      // إشعار الطالب عند اكتشاف جلسة مفتوحة جديدة (وليس في أول تحميل)
      if (knownSessionIdsRef.current === null) {
        knownSessionIdsRef.current = new Set(sessions.map((session) => session.id));
      } else {
        const newSessions = sessions.filter(
          (session) => !knownSessionIdsRef.current!.has(session.id)
        );
        if (newSessions.length > 0) {
          toast.info("فُتحت جلسة حضور جديدة — يمكنك تسجيل حضورك الآن");
          newSessions.forEach((session) => knownSessionIdsRef.current!.add(session.id));
        }
      }

      // التحقق من الجلسات التي سجّل فيها الطالب حضوره بالفعل
      if (sessions.length > 0) {
        const attended = await fetchAttendedSessionIds(
          user.id,
          sessions.map((session) => session.id)
        );
        setAttendedIds(attended);
      } else {
        setAttendedIds([]);
      }
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setLoadingSessions(false);
    }
  }, [user.id]);

  React.useEffect(() => {
    refreshOpenSessions();
  }, [refreshOpenSessions]);

  /* ------------------------------------------------------------------ */
  /*  جلب سجل الحضور السابق (مع بيانات الجلسة والدكتور المتداخلة)         */
  /* ------------------------------------------------------------------ */
  const loadHistory = React.useCallback(async () => {
    try {
      const rows = await fetchStudentHistory(user.id);
      setHistory(rows);
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setLoadingHistory(false);
    }
  }, [user.id]);

  React.useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  /* ------------------------------------------------------------------ */
  /*  الاشتراك اللحظي في تغيّرات جدول sessions:                            */
  /*  (Supabase Realtime أو استقصاء دوري في الوضع التجريبي)              */
  /* ------------------------------------------------------------------ */
  React.useEffect(() => {
    const unsubscribe = subscribeSessionUpdates(() => {
      refreshOpenSessions();
    });

    return unsubscribe;
  }, [refreshOpenSessions]);

  /* تحديث دوري احتياطي كل 30 ثانية (إذا تعذر الاتصال اللحظي) */
  React.useEffect(() => {
    const id = window.setInterval(() => refreshOpenSessions(), 30000);
    return () => window.clearInterval(id);
  }, [refreshOpenSessions]);

  /* ------------------------------------------------------------------ */
  /*  تسجيل الحضور الآن: إدراج صف في جدول attendance                       */
  /*  شرط أساسي: الجلسة مفتوحة من حساب الدكتور فقط + الطالب غير محظور      */
  /* ------------------------------------------------------------------ */
  async function handleCheckIn(session: SessionRow) {
    setCheckingIn(true);
    try {
      // تحقق أخير قبل الكتابة: الجلسة ما زالت مفتوحة؟ والطالب غير محظور؟
      const [freshSession, blocked] = await Promise.all([
        fetchSessionById(session.id),
        isStudentBlocked(session.professor_id, user.id),
      ]);

      if (!freshSession || !freshSession.is_open) {
        toast.error("الجلسة مقفولة الآن — لا يمكن تسجيل الحضور إلا والجلسة مفتوحة من حساب الدكتور");
        refreshOpenSessions();
        return;
      }

      if (blocked) {
        toast.error("أنت محظور من حضور محاضرات هذا الدكتور");
        return;
      }

      try {
        await insertAttendance({
          session_id: session.id,
          student_id: user.id,
          student_name: user.full_name,
          university_id: user.university_id,
        });
      } catch (error) {
        const code = (error as Error & { code?: string }).code;
        // حضور مكرر (القيد الفريد session_id + student_id — رمز 23505)
        if (code === "23505") {
          setAttendedIds((previous) => [...previous, session.id]);
          toast.info("حضورك مسجّل في هذه الجلسة بالفعل.");
          return;
        }
        // الجلسة قُفلت للتو على السيرفر
        if (code === "SESSION_CLOSED") {
          refreshOpenSessions();
          return;
        }
        throw error;
      }

      setAttendedIds((previous) => [...previous, session.id]);
      setJustCheckedInSessionId(session.id);
      toast.success(
        `تم تسجيل حضورك بنجاح في محاضرة ${
          session.users?.full_name ? `د. ${session.users.full_name}` : "اليوم"
        }`
      );
      loadHistory();
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setCheckingIn(false);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  العرض                                                               */
  /* ------------------------------------------------------------------ */

  return (
    <main className="relative flex min-h-screen flex-col">
      {/* الخلفية الزجاجية المتوهجة */}
      <div className="orbs" aria-hidden="true">
        <span className="orb orb-1" />
        <span className="orb orb-2" />
        <span className="orb orb-3" />
      </div>

      <AppHeader user={user} badge="لوحة الطالب" onLogout={onLogout} extra={<DemoBadge />} />

      <div className="relative z-10 mx-auto w-full max-w-6xl flex-1 space-y-5 px-4 py-6 sm:px-6">
        {/* الترحيب */}
        <section className="flex flex-wrap items-end justify-between gap-2 px-1">
          <div>
            <h1 className="text-2xl font-black text-foreground sm:text-[1.7rem]">
              {greetingForNow()} {user.full_name.split(" ")[0]}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {formatDate(new Date().toISOString())}
            </p>
          </div>
          <p className="text-xs font-bold text-muted-foreground" dir="ltr">
            {user.email}
          </p>
        </section>

        {/* البطاقة الرقمية + لوحة الجلسة الحالية */}
        <div className="grid items-start gap-4 sm:gap-6 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <DigitalIdCard user={user} />
          </div>
          <div className="lg:col-span-8">
            <SessionPanel
              openSessions={openSessions}
              loadingSessions={loadingSessions}
              attendedIds={attendedIds}
              justCheckedInSessionId={justCheckedInSessionId}
              checkingIn={checkingIn}
              onCheckIn={handleCheckIn}
              onRefresh={refreshOpenSessions}
            />
          </div>
        </div>

        {/* سجل الحضور السابق */}
        <HistoryTable history={history} loading={loadingHistory} />
      </div>

      {/* تذييل */}
      <footer className="relative z-10 py-5 text-center text-xs text-muted-foreground">
        ImIn — لوحة الطالب • تحقق جغرافي بمعادلة Haversine ورمز QR فريد
      </footer>
    </main>
  );
}
