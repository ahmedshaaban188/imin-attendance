"use client";

/**
 * ============================================================================
 *  ImIn | لوحة الطالب — البطاقة الجامعية الرقمية
 * ============================================================================
 *  - تعرض بيانات الطالب (الاسم، الرقم الجامعي، صورة الهوية) من جدول users
 *    المحفوظة في localStorage بعد الدخول
 *  - توليد QR Code حقيقي من الرقم الجامعي عبر مكتبة qrcode (QRCode.js)
 *  - توليد Barcode حقيقي (CODE128) من الرقم الجامعي عبر مكتبة jsbarcode
 *    الرمزان يوضعان على بلاطة بيضاء لضمان قابلية المسح في الوضعين الفاتح والداكن
 * ============================================================================
 */

import * as React from "react";
import QRCode from "qrcode";
import JsBarcode from "jsbarcode";
import { QrCode, ScanLine, BadgeCheck, CalendarDays } from "lucide-react";
import { formatShortDate } from "@/lib/format";
import type { AppUser } from "@/lib/types";

export function DigitalIdCard({ user }: { user: AppUser }) {
  const qrCanvasRef = React.useRef<HTMLCanvasElement>(null);
  const barcodeCanvasRef = React.useRef<HTMLCanvasElement>(null);
  const [barcodeSupported, setBarcodeSupported] = React.useState(true);

  /* ------------------ توليد رمز QR من الرقم الجامعي ------------------ */
  React.useEffect(() => {
    if (!qrCanvasRef.current || !user.university_id) return;

    QRCode.toCanvas(qrCanvasRef.current, user.university_id, {
      width: 220,
      margin: 2,
      errorCorrectionLevel: "M",
      color: {
        dark: "#29242f",
        light: "#ffffff",
      },
    }).catch((error) => {
      console.warn("ImIn: تعذر توليد رمز QR", error);
    });
  }, [user.university_id]);

  /* ---------------- توليد الباركود CODE128 من الرقم الجامعي ---------------- */
  React.useEffect(() => {
    if (!barcodeCanvasRef.current || !user.university_id) return;
    try {
      JsBarcode(barcodeCanvasRef.current, user.university_id, {
        format: "CODE128",
        width: 2,
        height: 58,
        displayValue: true,
        fontSize: 16,
        font: "monospace",
        fontOptions: "bold",
        textMargin: 4,
        margin: 6,
        lineColor: "#29242f",
        background: "#ffffff",
        valid: (isValid: boolean) => setBarcodeSupported(isValid),
      });
    } catch (error) {
      console.warn("ImIn: تعذر توليد الباركود", error);
      setBarcodeSupported(false);
    }
  }, [user.university_id]);

  const initials = user.full_name
    .split(" ")
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("");

  return (
    <section className="glass-card overflow-hidden" aria-label="البطاقة الجامعية الرقمية">
      {/* رأس البطاقة بتدرج بنفسجي */}
      <div className="btn-gradient flex items-center justify-between px-5 py-4">
        <div className="flex items-center gap-2.5">
          <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-white/20 text-white">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2.4}
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
              aria-hidden="true"
            >
              <path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z" />
              <path d="m8.5 11.2 2.4 2.4 4.6-4.9" />
            </svg>
          </span>
          <div className="leading-tight">
            <p className="text-base font-black text-white">ImIn</p>
            <p className="text-[11px] font-bold text-white/85">البطاقة الجامعية الرقمية</p>
          </div>
        </div>
        <span className="rounded-full bg-white/20 px-3 py-1 text-[11px] font-extrabold text-white">
          طالب
        </span>
      </div>

      {/* بيانات الطالب */}
      <div className="flex items-center gap-4 px-5 py-5">
        {user.id_card_url ? (
           
          <img
            src={user.id_card_url}
            alt={`صورة بطاقة ${user.full_name}`}
            className="h-24 w-20 shrink-0 rounded-2xl object-cover ring-2 ring-primary/25"
          />
        ) : (
          <span className="grid h-24 w-20 shrink-0 place-items-center rounded-2xl bg-primary/12 text-2xl font-black text-primary ring-2 ring-primary/20">
            {initials}
          </span>
        )}

        <div className="min-w-0 flex-1">
          <p className="truncate text-lg font-black leading-snug text-foreground">
            {user.full_name}
          </p>
          <p className="mt-1.5 flex items-center gap-1.5 text-sm font-extrabold tabular-nums text-primary" dir="ltr">
            <BadgeCheck className="h-4 w-4 shrink-0" />
            {user.university_id}
          </p>
          <p className="mt-1 truncate text-xs text-muted-foreground" dir="ltr">
            {user.email}
          </p>
          <p className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
            <CalendarDays className="h-3.5 w-3.5" />
            عضو منذ {formatShortDate(user.created_at)}
          </p>
        </div>
      </div>

      {/* رمز QR */}
      <div className="px-5 pb-2">
        <div className="flex items-center gap-4">
          <div className="code-tile shrink-0">
            <canvas
              ref={qrCanvasRef}
              className="block h-[176px] w-[176px]"
              role="img"
              aria-label={`رمز QR الخاص بالرقم الجامعي ${user.university_id}`}
            />
          </div>
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 text-sm font-extrabold text-foreground">
              <QrCode className="h-4 w-4 text-primary" />
              رمز التحقق السريع
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
              رمز QR فريد يتولّد تلقائياً من رقمك الجامعي — يعرضه الدكتور للتحقق من هويتك
              بضغطة واحدة.
            </p>
          </div>
        </div>
      </div>

      {/* الباركود */}
      <div className="px-5 pb-5 pt-3">
        {barcodeSupported ? (
          <div className="code-tile overflow-hidden">
            <canvas
              ref={barcodeCanvasRef}
              className="block w-full"
              role="img"
              aria-label={`باركود CODE128 خاص بالرقم الجامعي ${user.university_id}`}
            />
          </div>
        ) : (
          <div className="rounded-xl bg-white/70 dark:bg-white/10 px-4 py-3 text-center text-xs font-bold text-muted-foreground" dir="ltr">
            {user.university_id}
          </div>
        )}
        <p className="mt-2 flex items-center justify-center gap-1.5 text-[11px] font-bold text-muted-foreground">
          <ScanLine className="h-3.5 w-3.5" />
          باركود CODE128 — قابل للمسح بالماسحات الضوئية
        </p>
      </div>
    </section>
  );
}
