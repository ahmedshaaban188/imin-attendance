"use client";

/**
 * ============================================================================
 *  ImIn | لوحة الطالب — سجل حضور المحاضرات السابقة
 * ============================================================================
 *  يعرض سجل حضور الطالب من جدول attendance مع تفاصيل الجلسة
 *  (اسم الدكتور عبر العلاقة sessions -> users) في جدول منسّق.
 * ============================================================================
 */

import * as React from "react";
import { History, CheckCircle2, UserRound } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, formatTime } from "@/lib/format";
import type { AttendanceRow } from "@/lib/types";

/** صف الحضور مع بيانات الجلسة المتداخلة (sessions -> users) */
export interface HistoryRow extends AttendanceRow {
  sessions:
    | {
        created_at: string;
        radius: number;
        users: { full_name: string } | null;
      }
    | null;
}

export interface HistoryTableProps {
  history: HistoryRow[];
  loading: boolean;
}

export function HistoryTable({ history, loading }: HistoryTableProps) {
  return (
    <section className="glass-card p-5 sm:p-6" aria-label="سجل حضور المحاضرات السابقة">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="flex items-center gap-2.5 text-lg font-black">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/12 text-primary">
            <History className="h-5 w-5" />
          </span>
          سجل حضور المحاضرات
          <span className="rounded-full bg-primary/12 px-2.5 py-0.5 text-sm font-black tabular-nums text-primary">
            {history.length}
          </span>
        </h2>
      </header>

      <div className="mt-4">
        {loading ? (
          <div className="space-y-2.5">
            {Array.from({ length: 4 }).map((_, index) => (
              <Skeleton key={index} className="h-14 w-full rounded-xl" />
            ))}
          </div>
        ) : history.length === 0 ? (
          <div
            className="flex h-44 flex-col items-center justify-center gap-2.5 rounded-2xl border-2 border-dashed border-border text-center"
            aria-label="لا سجل حضور بعد"
          >
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-muted text-muted-foreground">
              <UserRound className="h-6 w-6" />
            </span>
            <p className="text-sm font-bold text-muted-foreground">
              لا يوجد سجل حضور بعد
            </p>
            <p className="text-xs text-muted-foreground/80">
              سجّل حضورك في أول جلسة وسيظهر هنا فوراً
            </p>
          </div>
        ) : (
          <div className="nice-scroll max-h-[24rem] overflow-y-auto pe-1">
            <Table>
              <TableHeader className="sticky top-0 z-10 bg-white/70 backdrop-blur dark:bg-[#161923]/80">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-start">التاريخ</TableHead>
                  <TableHead className="text-start">المحاضر</TableHead>
                  <TableHead className="text-start">وقت تسجيل الحضور</TableHead>
                  <TableHead className="text-start">الحالة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {history.map((row) => (
                  <TableRow
                    key={row.id}
                    className="row-enter bg-white/35 dark:bg-white/4 hover:bg-white/60 dark:hover:bg-white/8"
                  >
                    <TableCell className="py-3.5 text-sm font-bold">
                      {row.sessions ? formatDate(row.sessions.created_at) : "—"}
                    </TableCell>
                    <TableCell className="py-3.5 text-sm font-extrabold text-primary">
                      {row.sessions?.users?.full_name
                        ? `د. ${row.sessions.users.full_name}`
                        : "—"}
                    </TableCell>
                    <TableCell className="py-3.5 text-sm font-black tabular-nums">
                      {formatTime(row.created_at)}
                    </TableCell>
                    <TableCell className="py-3.5">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/12 px-3 py-1 text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        حاضر
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </section>
  );
}
