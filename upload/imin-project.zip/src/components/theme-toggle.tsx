"use client";

/**
 * ImIn | زر تبديل الوضع الفاتح/الداكن مع انتقال سلس
 */

import * as React from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";

export function ThemeToggle() {
  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  const isDark = resolvedTheme === "dark";

  return (
    <button
      type="button"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      aria-label={isDark ? "التبديل إلى الوضع الفاتح" : "التبديل إلى الوضع الداكن"}
      title={isDark ? "الوضع الفاتح" : "الوضع الداكن"}
      className="glass-chip inline-flex h-11 w-11 items-center justify-center rounded-full text-foreground/80 hover:text-primary hover:scale-105 active:scale-95 transition-all"
    >
      {mounted ? (
        isDark ? (
          <Sun className="h-5 w-5" strokeWidth={2.2} />
        ) : (
          <Moon className="h-5 w-5" strokeWidth={2.2} />
        )
      ) : (
        <span className="h-5 w-5" />
      )}
    </button>
  );
}
