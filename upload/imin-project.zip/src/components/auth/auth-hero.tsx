"use client";

/**
 * ImIn | القسم التعريفي في صفحة الدخول
 * (يظهر على الشاشات الكبيرة بجانب نموذج المصادقة)
 */

import { LocateFixed, QrCode, Radio, Moon, MapPin, ScanLine } from "lucide-react";
import { Logo } from "@/components/logo";

const FEATURES = [
  {
    icon: LocateFixed,
    title: "تحقق جغرافي فوري",
    description: "قياس المسافة بنطاق أمتار حول قاعة المحاضرة عبر GPS ومعادلة Haversine.",
  },
  {
    icon: QrCode,
    title: "بطاقة رقمية QR + Barcode",
    description: "رمز فريد يتولّد تلقائياً من رقمك الجامعي ويمكن مسحه للتحقق.",
  },
  {
    icon: Radio,
    title: "حضور لحظي Real-time",
    description: "يظهر حضور الطلاب أمام الدكتور لحظة بلحظة دون تحديث الصفحة.",
  },
  {
    icon: Moon,
    title: "وضع داكن أنيق",
    description: "تصميم زجاجي (Glassmorphism) بتبديل سلس بين الفاتح والداكن.",
  },
];

export function AuthHero() {
  return (
    <section className="hidden lg:flex flex-col justify-center gap-8 ps-4">
      {/* بطاقات زجاجية عائمة زخرفية */}
      <div className="pointer-events-none absolute -top-6 start-8 hidden xl:block" aria-hidden="true">
        <div className="glass-card px-5 py-4 flex items-center gap-3 animate-float-y">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
            <QrCode className="h-5 w-5" />
          </span>
          <div className="text-start">
            <p className="text-sm font-extrabold">رقمك الجامعي</p>
            <p className="text-xs text-muted-foreground" dir="ltr">2023 • 04571</p>
          </div>
        </div>
      </div>
      <div
        className="pointer-events-none absolute bottom-10 start-24 hidden xl:block"
        aria-hidden="true"
      >
        <div
          className="glass-card px-5 py-4 flex items-center gap-3 animate-float-y"
          style={{ animationDelay: "1.4s" }}
        >
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
            <MapPin className="h-5 w-5" />
          </span>
          <div className="text-start">
            <p className="text-sm font-extrabold">داخل النطاق</p>
            <p className="text-xs text-muted-foreground">المسافة 23 متراً</p>
          </div>
        </div>
      </div>

      <Logo size={52} tagline="نظام الحضور الجامعي الذكي" />

      <div>
        <h1 className="text-4xl xl:text-[2.9rem] font-black leading-[1.25] text-foreground">
          حضورك الجامعي،
          <br />
          <span className="text-gradient">بضغطة واحدة.</span>
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted-foreground max-w-md">
          يوثّق ImIn حضور المحاضرات عبر التحقق الجغرافي بدقة الأمتار، مع بطاقة QR رقمية لكل
          طالب، ولوحة لحظية تعرض الحضور أمام الدكتور مباشرةً.
        </p>
      </div>

      <ul className="grid sm:grid-cols-2 gap-3 max-w-xl">
        {FEATURES.map((feature) => (
          <li key={feature.title} className="glass-card p-4 flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/12 text-primary">
              <feature.icon className="h-5 w-5" strokeWidth={2.1} />
            </span>
            <div>
              <p className="text-sm font-extrabold text-foreground">{feature.title}</p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          </li>
        ))}
      </ul>

      <p className="flex items-center gap-2 text-xs text-muted-foreground">
        <ScanLine className="h-4 w-4" />
        يدعم الدخول عبر البريد الإلكتروني والرقم الجامعي — بدون كلمات مرور حسب مخطط قاعدة
        البيانات.
      </p>
    </section>
  );
}
