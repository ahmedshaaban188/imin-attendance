"use client";

/**
 * ============================================================================
 *  ImIn | صفحة المصادقة والتسجيل (مكافئ index.html)
 * ============================================================================
 *  - تسجيل الدخول عبر البريد الإلكتروني + الرقم الجامعي/الوظيفي
 *  - إنشاء حساب جديد (طالب / دكتور) مع رفع صورة البطاقة الشخصية إلى
 *    Supabase Storage (bucket: id-cards) وحفظ بيانات المستخدم في جدول users
 *  - بعد النجاح تُحفظ البيانات في localStorage ثم يُحوَّل المستخدم إلى لوحته
 * ============================================================================
 */

import * as React from "react";
import {
  GraduationCap,
  BookOpen,
  Loader2,
  LogIn,
  UserRound,
  Mail,
  Hash,
  Upload,
  X,
  Camera,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/logo";
import { ThemeToggle } from "@/components/theme-toggle";
import { DemoBadge } from "@/components/demo-badge";
import { AuthHero } from "@/components/auth/auth-hero";
import {
  findUserByLogin,
  emailExists,
  uploadIdCard,
  insertUser,
} from "@/lib/data-layer";
import { friendlyError, saveUserToLocalStorage } from "@/lib/supabaseClient";
import type { AppUser, UserRole } from "@/lib/types";

/* -------------------------------------------------------------------------- */
/*  أدوات مساعدة                                                              */
/* -------------------------------------------------------------------------- */

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const UNIVERSITY_ID_REGEX = /^[A-Za-z0-9\u0600-\u06FF-]{3,25}$/;
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

/** ضغط صورة البطاقة قبل الرفع (أبعاد أقصى 1280px بصيغة JPEG) */
async function compressImage(file: File): Promise<Blob> {
  try {
    const bitmap = await createImageBitmap(file);
    const maxDim = 1280;
    const scale = Math.min(1, maxDim / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) return file;
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, "image/jpeg", 0.85)
    );
    return blob && blob.size < file.size ? blob : file;
  } catch {
    return file;
  }
}

/* -------------------------------------------------------------------------- */
/*  مكوّن الصفحة                                                               */
/* -------------------------------------------------------------------------- */

type AuthMode = "login" | "register";

export function AuthView({ onSuccess }: { onSuccess: (user: AppUser) => void }) {
  const [mode, setMode] = React.useState<AuthMode>("login");
  const [busy, setBusy] = React.useState(false);
  const [dragOver, setDragOver] = React.useState(false);

  // حقول تسجيل الدخول
  const [loginEmail, setLoginEmail] = React.useState("");
  const [loginId, setLoginId] = React.useState("");

  // حقول إنشاء الحساب
  const [fullName, setFullName] = React.useState("");
  const [registerEmail, setRegisterEmail] = React.useState("");
  const [universityId, setUniversityId] = React.useState("");
  const [role, setRole] = React.useState<UserRole>("student");
  const [idCardFile, setIdCardFile] = React.useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = React.useState<string | null>(null);

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const idLabel = role === "student" ? "الرقم الجامعي" : "الرقم الوظيفي";
  const idPlaceholder = role === "student" ? "مثال: 202304571" : "مثال: prof-1024";

  /* ------------------------- إدارة ملف البطاقة ------------------------- */

  React.useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  function pickFile(file: File | undefined | null) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("الملف المختار ليس صورة — اختر صورة البطاقة بصيغة PNG أو JPG.");
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      toast.error("حجم الصورة كبير — الحد الأقصى 5 ميجابايت.");
      return;
    }
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setIdCardFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  }

  function clearFile() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setIdCardFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  /* --------------------------- تسجيل الدخول --------------------------- */

  async function handleLogin(event: React.FormEvent) {
    event.preventDefault();
    const email = loginEmail.trim().toLowerCase();
    const idNumber = loginId.trim();

    if (!EMAIL_REGEX.test(email)) {
      toast.error("أدخل بريداً إلكترونياً صحيحاً.");
      return;
    }
    if (!UNIVERSITY_ID_REGEX.test(idNumber)) {
      toast.error("أدخل رقمك الجامعي/الوظيفي كما سجّلته عند إنشاء الحساب.");
      return;
    }

    setBusy(true);
    try {
      const user = await findUserByLogin(email, idNumber);

      if (!user) {
        toast.error("أنت غير مسجل في نظام ImIn — أنشئ حساباً جديداً أولاً");
        return;
      }

      saveUserToLocalStorage(user);
      toast.success(`مرحباً يا ${user.full_name.split(" ")[0]}`);
      onSuccess(user);
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setBusy(false);
    }
  }

  /* ---------------------------- إنشاء حساب ---------------------------- */

  async function handleRegister(event: React.FormEvent) {
    event.preventDefault();
    const name = fullName.trim();
    const email = registerEmail.trim().toLowerCase();
    const idNumber = universityId.trim();

    // التحقق من الحقول
    if (name.length < 3 || !name.includes(" ")) {
      toast.error("أدخل الاسم الكامل (الاسم الأول واسم العائلة).");
      return;
    }
    if (!EMAIL_REGEX.test(email)) {
      toast.error("أدخل بريداً إلكترونياً صحيحاً.");
      return;
    }
    if (!UNIVERSITY_ID_REGEX.test(idNumber)) {
      toast.error("الرقم الجامعي/الوظيفي يجب أن يكون من 3 إلى 25 حرفاً أو رقماً.");
      return;
    }
    if (role === "student" && !idCardFile) {
      toast.error("صورة البطاقة الجامعية إلزامية للطلاب.");
      return;
    }

    setBusy(true);
    try {
      // 1) التأكد أن البريد غير مستخدم مسبقاً
      const exists = await emailExists(email);
      if (exists) {
        toast.error("هذا البريد الإلكتروني مسجّل مسبقاً — يمكنك تسجيل الدخول مباشرة.");
        return;
      }

      // 2) رفع صورة البطاقة (إلى Supabase Storage أو تخزينها في الوضع التجريبي)
      let idCardUrl: string | null = null;
      if (idCardFile) {
        const blob = await compressImage(idCardFile);
        const safeName = idNumber.replace(/[^\w\u0600-\u06FF-]/g, "_");
        const extension = blob.type === "image/png" ? "png" : "jpg";
        const path = `${safeName}-${Date.now()}.${extension}`;
        idCardUrl = await uploadIdCard(path, blob);
      }

      // 3) حفظ بيانات المستخدم في جدول users
      const user = await insertUser({
        full_name: name,
        email,
        university_id: idNumber,
        role,
        id_card_url: idCardUrl,
      });

      saveUserToLocalStorage(user);
      toast.success(
        role === "student"
          ? "تم إنشاء حسابك بنجاح — مرحباً بك في ImIn"
          : "تم إنشاء حساب الدكتور بنجاح — يمكنك الآن فتح أول جلسة حضور"
      );
      onSuccess(user);
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setBusy(false);
    }
  }

  /* ------------------------------- العرض ------------------------------- */

  return (
    <main className="relative min-h-screen flex flex-col">
      {/* الخلفية الزجاجية المتوهجة */}
      <div className="orbs" aria-hidden="true">
        <span className="orb orb-1" />
        <span className="orb orb-2" />
        <span className="orb orb-3" />
      </div>

      {/* شريط علوي مصغّر */}
      <header className="relative z-10 mx-auto flex w-full max-w-5xl items-center justify-between gap-3 px-4 pt-6">
        <div className="lg:hidden">
          <Logo size={36} />
        </div>
        <div className="hidden lg:block" />
        <div className="flex items-center gap-2">
          <DemoBadge />
          <ThemeToggle />
        </div>
      </header>

      {/* المحتوى */}
      <div className="relative z-10 flex flex-1 items-center justify-center px-4 py-8 sm:py-10">
        <div className="w-full max-w-5xl">
          <div className="grid gap-8 lg:grid-cols-2 lg:items-center xl:gap-14">
            <div className="relative">
              <AuthHero />
            </div>

            {/* بطاقة المصادقة الزجاجية */}
            <section
              className="glass-card p-6 sm:p-8 mx-auto w-full max-w-md"
              aria-label="نموذج تسجيل الدخول وإنشاء الحساب"
            >
              {/* مبدّل الوضع */}
              <div className="glass-chip grid grid-cols-2 gap-1 rounded-2xl p-1.5">
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className={`h-10 rounded-xl text-sm font-bold transition-all ${
                    mode === "login"
                      ? "btn-gradient"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  تسجيل الدخول
                </button>
                <button
                  type="button"
                  onClick={() => setMode("register")}
                  className={`h-10 rounded-xl text-sm font-bold transition-all ${
                    mode === "register"
                      ? "btn-gradient"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  حساب جديد
                </button>
              </div>

              {mode === "login" ? (
                /* ------------------- نموذج تسجيل الدخول ------------------- */
                <form onSubmit={handleLogin} className="mt-7 space-y-5" noValidate>
                  <div className="text-center">
                    <h2 className="text-xl font-black text-foreground">أهلاً بعودتك</h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      سجّل دخولك للوصول إلى لوحتك
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-email" className="text-sm font-bold">
                      البريد الإلكتروني
                    </Label>
                    <div className="relative">
                      <Mail className="pointer-events-none absolute start-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="login-email"
                        type="email"
                        dir="ltr"
                        className="input-glass ps-11"
                        placeholder="you@university.edu"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        autoComplete="email"
                        disabled={busy}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-id" className="text-sm font-bold">
                      الرقم الجامعي / الوظيفي
                    </Label>
                    <div className="relative">
                      <Hash className="pointer-events-none absolute start-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="login-id"
                        type="text"
                        dir="ltr"
                        className="input-glass ps-11"
                        placeholder="202304571"
                        value={loginId}
                        onChange={(e) => setLoginId(e.target.value)}
                        disabled={busy}
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="btn-gradient h-12 w-full rounded-2xl text-base font-extrabold"
                    disabled={busy}
                  >
                    {busy ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <>
                        <LogIn className="h-5 w-5" />
                        تسجيل الدخول
                      </>
                    )}
                  </Button>

                  <p className="text-center text-xs text-muted-foreground">
                    ليس لديك حساب؟{" "}
                    <button
                      type="button"
                      onClick={() => setMode("register")}
                      className="font-bold text-primary hover:underline"
                    >
                      أنشئ حساباً جديداً
                    </button>
                  </p>
                </form>
              ) : (
                /* ------------------- نموذج إنشاء حساب جديد ------------------- */
                <form onSubmit={handleRegister} className="mt-7 space-y-5" noValidate>
                  <div className="text-center">
                    <h2 className="text-xl font-black text-foreground">إنشاء حساب جديد</h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      انضم إلى ImIn في أقل من دقيقة
                    </p>
                  </div>

                  {/* اختيار الدور */}
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setRole("student")}
                      aria-pressed={role === "student"}
                      className={`rounded-2xl border p-4 flex flex-col items-center gap-2 transition-all ${
                        role === "student"
                          ? "border-primary bg-primary/10 shadow-[0_0_0_3px_rgba(139,92,246,0.15)]"
                          : "border-border bg-white/40 dark:bg-white/5 hover:border-primary/50"
                      }`}
                    >
                      <GraduationCap
                        className={`h-7 w-7 ${role === "student" ? "text-primary" : "text-muted-foreground"}`}
                      />
                      <span className="text-sm font-extrabold">طالب</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole("professor")}
                      aria-pressed={role === "professor"}
                      className={`rounded-2xl border p-4 flex flex-col items-center gap-2 transition-all ${
                        role === "professor"
                          ? "border-primary bg-primary/10 shadow-[0_0_0_3px_rgba(139,92,246,0.15)]"
                          : "border-border bg-white/40 dark:bg-white/5 hover:border-primary/50"
                      }`}
                    >
                      <BookOpen
                        className={`h-7 w-7 ${role === "professor" ? "text-primary" : "text-muted-foreground"}`}
                      />
                      <span className="text-sm font-extrabold">دكتور</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-name" className="text-sm font-bold">
                      الاسم الكامل
                    </Label>
                    <div className="relative">
                      <UserRound className="pointer-events-none absolute start-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="register-name"
                        type="text"
                        className="input-glass ps-11"
                        placeholder="محمد أحمد عبد الرحمن"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        disabled={busy}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="register-email" className="text-sm font-bold">
                        البريد الإلكتروني
                      </Label>
                      <div className="relative">
                        <Mail className="pointer-events-none absolute start-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          id="register-email"
                          type="email"
                          dir="ltr"
                          className="input-glass ps-11"
                          placeholder="you@university.edu"
                          value={registerEmail}
                          onChange={(e) => setRegisterEmail(e.target.value)}
                          autoComplete="email"
                          disabled={busy}
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-id" className="text-sm font-bold">
                        {idLabel}
                      </Label>
                      <div className="relative">
                        <Hash className="pointer-events-none absolute start-4 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          id="register-id"
                          type="text"
                          dir="ltr"
                          className="input-glass ps-11"
                          placeholder={idPlaceholder}
                          value={universityId}
                          onChange={(e) => setUniversityId(e.target.value)}
                          disabled={busy}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* رفع صورة البطاقة */}
                  <div className="space-y-2">
                    <Label className="text-sm font-bold">
                      صورة البطاقة الشخصية{" "}
                      <span className="font-medium text-muted-foreground">
                        ({role === "student" ? "إلزامية" : "اختيارية"})
                      </span>
                    </Label>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => pickFile(e.target.files?.[0])}
                      aria-label="اختيار صورة البطاقة"
                    />
                    {previewUrl && idCardFile ? (
                      <div className="drop-zone relative flex items-center gap-4 p-3">
                        { }
                        <img
                          src={previewUrl}
                          alt="معاينة صورة البطاقة"
                          className="h-16 w-24 rounded-xl object-cover ring-1 ring-border"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold" dir="ltr">
                            {idCardFile.name}
                          </p>
                          <p className="text-xs text-muted-foreground" dir="ltr">
                            {(idCardFile.size / 1024).toFixed(0)} KB
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={clearFile}
                          className="glass-chip grid h-9 w-9 place-items-center rounded-full text-foreground/70 hover:text-destructive"
                          aria-label="إزالة الصورة"
                        >
                          <X className="h-4.5 w-4.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        onDragOver={(e) => {
                          e.preventDefault();
                          setDragOver(true);
                        }}
                        onDragLeave={() => setDragOver(false)}
                        onDrop={(e) => {
                          e.preventDefault();
                          setDragOver(false);
                          pickFile(e.dataTransfer.files?.[0]);
                        }}
                        className={`drop-zone flex w-full flex-col items-center gap-2 px-4 py-6 ${
                          dragOver ? "dragover" : ""
                        }`}
                      >
                        <span className="grid h-12 w-12 place-items-center rounded-full bg-primary/12 text-primary">
                          {dragOver ? (
                            <Camera className="h-6 w-6" />
                          ) : (
                            <Upload className="h-6 w-6" />
                          )}
                        </span>
                        <span className="text-sm font-bold text-foreground">
                          اسحب صورة البطاقة هنا أو اضغط للاختيار
                        </span>
                        <span className="text-xs text-muted-foreground">
                          PNG أو JPG — بحد أقصى 5MB (يتم ضغطها تلقائياً قبل الرفع)
                        </span>
                      </button>
                    )}
                  </div>

                  <Button
                    type="submit"
                    className="btn-gradient h-12 w-full rounded-2xl text-base font-extrabold"
                    disabled={busy}
                  >
                    {busy ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      "إنشاء الحساب والانتقال إلى اللوحة"
                    )}
                  </Button>

                  <p className="text-center text-xs text-muted-foreground">
                    لديك حساب بالفعل؟{" "}
                    <button
                      type="button"
                      onClick={() => setMode("login")}
                      className="font-bold text-primary hover:underline"
                    >
                      سجّل دخولك من هنا
                    </button>
                  </p>
                </form>
              )}
            </section>
          </div>
        </div>
      </div>

      {/* تذييل */}
      <footer className="relative z-10 py-5 text-center text-xs text-muted-foreground">
        <p className="font-extrabold text-foreground/70">ImIn — نظام الحضور الجامعي</p>
        <p className="mt-0.5">
          By <span className="font-bold">Ahmed Shaban</span>
        </p>
      </footer>
    </main>
  );
}
