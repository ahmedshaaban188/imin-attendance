"use client";

/**
 * ============================================================================
 *  ImIn | لوحة الدكتور — قائمة الحضور (اللحظي + حضور آخر جلسة)
 * ============================================================================
 *  - تعرض الطلاب لحظة تسجيلهم حضورهم (Realtime) وتبقى ظاهرة بعد إنهاء الجلسة
 *  - لكل طالب: الاسم + الإيميل الجامعي + الرقم الجامعي + صورة البطاقة (اضغط
 *    على الصورة لعرض الملف كاملاً) + عدد الحضور والغياب والإنذارات
 *  - زر "بلوك" لحظر الطالب (فصله من المادة) فلا يستطيع تسجيل الحضور مجدداً
 *  - زر "إنذار" لتسجيل إنذار جديد على الطالب
 *  - تصدير السجل كاملاً بصيغة CSV (متوافق مع Excel بالعربية عبر BOM)
 * ============================================================================
 */

import * as React from "react";
import {
  AlertTriangle,
  Ban,
  Camera,
  Download,
  Mail,
  Radio,
  ShieldCheck,
  Users,
  UserRound,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatTime, relativeTime } from "@/lib/format";
import type {
  AppUser,
  AttendanceRow,
  ProfessorRosterStats,
  RealtimeStatus,
} from "@/lib/types";

const AVATAR_GRADIENTS = [
  "from-violet-500 to-fuchsia-500",
  "from-emerald-500 to-teal-500",
  "from-rose-500 to-orange-400",
  "from-amber-500 to-yellow-400",
  "from-cyan-500 to-emerald-400",
];

function initialsOf(fullName: string): string {
  return fullName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0))
    .join("");
}

/** حماية خلايا CSV (علامات الاقتباس المزدوجة) */
function csvCell(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

export interface LiveAttendanceProps {
  attendance: AttendanceRow[];
  status: RealtimeStatus;
  loading: boolean;
  /** هل القائمة مرتبطة بجلسة مفتوحة الآن؟ */
  isLiveSession: boolean;
  /** التوقيت الحالي لتحديث الأزمنة النسبية */
  now: number;
  /** ملفات الطلاب (الإيميل الجامعي + صورة البطاقة) حسب المعرف */
  profilesById: Record<string, AppUser>;
  /** إحصائيات الحضور/الغياب/الإنذارات/المحظورين */
  stats: ProfessorRosterStats | null;
  /** حظر طالب أو فك الحظر عنه */
  onToggleBlock: (studentId: string, currentlyBlocked: boolean) => void;
  /** تسجيل إنذار على طالب */
  onWarn: (studentId: string, studentName: string) => void;
  /** معرف الطالب الجاري تنفيذ إجراء عليه الآن (بلوك/إنذار) */
  actionBusyStudentId: string | null;
}

export function LiveAttendance({
  attendance,
  status,
  loading,
  isLiveSession,
  now,
  profilesById,
  stats,
  onToggleBlock,
  onWarn,
  actionBusyStudentId,
}: LiveAttendanceProps) {
  const [viewing, setViewing] = React.useState<AppUser | null>(null);

  const actionsBusy = actionBusyStudentId !== null;

  /* ------------------- إحصائيات طالب معين لدى الدكتور ------------------- */

  function statsOf(studentId: string) {
    const attended = stats ? (stats.attendedByStudent[studentId] ?? 0) : 0;
    const absences = stats
      ? Math.max(
          0,
          stats.totalClosedSessions -
            (stats.closedAttendedByStudent[studentId] ?? 0)
        )
      : 0;
    const warnings = stats ? (stats.warningsByStudent[studentId] ?? 0) : 0;
    const blocked = stats ? stats.blockedIds.includes(studentId) : false;
    return { attended, absences, warnings, blocked };
  }

  const viewingStats = viewing ? statsOf(viewing.id) : null;

  /* ------------------------- تصدير السجل CSV ------------------------- */

  function exportCsv() {
    if (attendance.length === 0) return;

    const header =
      "الاسم الكامل,البريد الجامعي,الرقم الجامعي,وقت تسجيل الحضور,عدد الحضور,عدد الغياب,عدد الإنذارات,الحالة";
    const rows = attendance
      .map((row) => {
        const { attended, absences, warnings, blocked } = statsOf(
          row.student_id
        );
        const email = profilesById[row.student_id]?.email ?? "";
        const time = new Date(row.created_at).toLocaleString("ar-EG-u-nu-latn");
        return [
          csvCell(row.student_name),
          csvCell(email),
          csvCell(row.university_id),
          time,
          String(attended),
          String(absences),
          String(warnings),
          blocked ? "محظور" : "نشط",
        ].join(",");
      })
      .join("\n");

    const csv = `\uFEFF${header}\n${rows}`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `imin-attendance-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  const statusLabel =
    status === "live"
      ? "متصل مباشرة"
      : status === "connecting"
        ? "جارٍ الاتصال..."
        : status === "error"
          ? "تعذر الاتصال اللحظي"
          : "غير متصل";

  /** الطلاب المحظورون غير الموجودين في قائمة الحضور الحالية */
  const blockedOnlyStudents = (stats?.blockedIds ?? []).filter(
    (studentId) => !attendance.some((row) => row.student_id === studentId)
  );

  /* ------------------------------- العرض ------------------------------ */

  return (
    <section className="glass-card flex flex-col p-5 sm:p-6" aria-label="قائمة الحضور">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="flex items-center gap-2.5 text-lg font-black">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/12 text-primary">
            <Users className="h-5 w-5" />
          </span>
          {isLiveSession ? "الحضور اللحظي" : "حضور آخر جلسة"}
          <span className="rounded-full bg-primary/12 px-2.5 py-0.5 text-sm font-black tabular-nums text-primary">
            {attendance.length}
          </span>
        </h2>

        <div className="flex items-center gap-2.5">
          {isLiveSession && (
            <span
              className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ${
                status === "live"
                  ? "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400"
                  : status === "error"
                    ? "bg-rose-500/12 text-rose-600 dark:text-rose-400"
                    : "bg-amber-500/12 text-amber-600 dark:text-amber-400"
              }`}
              title={`حالة الاتصال اللحظي: ${statusLabel}`}
            >
              <span className={`live-dot ${status === "error" ? "live-dot--error" : ""}`} />
              <Radio className="h-3 w-3" />
              {statusLabel}
            </span>
          )}
          <button
            type="button"
            onClick={exportCsv}
            disabled={attendance.length === 0}
            aria-label="تصدير سجل الحضور بصيغة CSV"
            title="تصدير CSV (يفتح في Excel)"
            className="glass-chip inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-xs font-bold text-foreground/80 transition-all hover:text-primary disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="h-3.5 w-3.5" />
            تصدير CSV
          </button>
        </div>
      </header>

      {/* القائمة */}
      <div className="mt-4 flex-1">
        {loading ? (
          <div className="space-y-2.5" aria-label="جارٍ تحميل قائمة الحضور">
            {Array.from({ length: 3 }).map((_, index) => (
              <div
                key={index}
                className="flex items-center gap-3 rounded-2xl border border-border/60 bg-white/35 dark:bg-white/4 px-4 py-3"
              >
                <Skeleton className="h-11 w-11 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-4 w-32 rounded-full" />
                  <Skeleton className="h-3 w-44 rounded-full" />
                </div>
                <Skeleton className="h-5 w-14 rounded-full" />
              </div>
            ))}
          </div>
        ) : attendance.length === 0 && blockedOnlyStudents.length === 0 ? (
          <div
            className="flex h-64 flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border text-center"
            aria-label="لا يوجد حضور بعد"
          >
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-muted text-muted-foreground">
              <UserRound className="h-7 w-7" />
            </span>
            <p className="text-sm font-bold text-muted-foreground">
              {isLiveSession
                ? "لم يسجّل أحد حضوره بعد"
                : "لا حضور مسجّل في آخر جلسة"}
            </p>
            <p className="max-w-[240px] text-xs leading-relaxed text-muted-foreground/80">
              {isLiveSession
                ? "ستظهر أسماء الطلاب هنا تلقائياً ولحظياً بمجرد تسجيلهم الحضور من داخل النطاق."
                : "ابدأ جلسة جديدة وسيوثّق الطلاب حضورهم فيها."}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {/* الطلاب المحظورون غير الحاضرين في هذه القائمة */}
            {blockedOnlyStudents.length > 0 && (
              <div className="rounded-2xl border border-rose-500/25 bg-rose-500/5 px-4 py-3">
                <p className="flex items-center gap-2 text-xs font-extrabold text-rose-600 dark:text-rose-400">
                  <Ban className="h-4 w-4" />
                  الطلاب المحظورون (مفصولون من المادة)
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {blockedOnlyStudents.map((studentId) => (
                    <span
                      key={studentId}
                      className="inline-flex items-center gap-2 rounded-full bg-rose-500/10 px-3 py-1.5 text-xs font-bold text-foreground"
                    >
                      {profilesById[studentId]?.full_name ?? "طالب"}
                      <button
                        type="button"
                        onClick={() => onToggleBlock(studentId, true)}
                        disabled={actionsBusy}
                        className="grid h-6 w-6 place-items-center rounded-full text-emerald-600 transition-colors hover:bg-emerald-500/15 dark:text-emerald-400"
                        title="فك الحظر والسماح بالحضور مجدداً"
                        aria-label="فك الحظر"
                      >
                        <ShieldCheck className="h-3.5 w-3.5" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* قائمة الحضور ببياناتها الكاملة */}
            <ul className="nice-scroll max-h-[30rem] space-y-2.5 overflow-y-auto pe-1" dir="rtl">
              {attendance.map((row, index) => {
                const profile = profilesById[row.student_id];
                const { attended, absences, warnings, blocked } = statsOf(
                  row.student_id
                );
                const busy = actionsBusy;

                return (
                  <li
                    key={row.id}
                    className={`row-enter rounded-2xl border px-4 py-3 transition-colors ${
                      blocked
                        ? "border-rose-500/40 bg-rose-500/5"
                        : "border-border/60 bg-white/45 dark:bg-white/5 hover:bg-white/65 dark:hover:bg-white/8"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {/* صورة البطاقة — اضغط لعرض الملف كاملاً */}
                      <button
                        type="button"
                        onClick={() => profile && setViewing(profile)}
                        className="relative shrink-0 rounded-full disabled:cursor-default"
                        disabled={!profile}
                        title={profile ? "عرض ملف الطالب وصورة البطاقة" : undefined}
                        aria-label={
                          profile
                            ? `عرض ملف الطالب ${row.student_name}`
                            : undefined
                        }
                      >
                        {profile?.id_card_url ? (
                          <img
                            src={profile.id_card_url}
                            alt=""
                            className="h-11 w-11 rounded-full object-cover ring-2 ring-border"
                          />
                        ) : (
                          <span
                            className={`grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br text-sm font-black text-white ${
                              AVATAR_GRADIENTS[index % AVATAR_GRADIENTS.length]
                            }`}
                            aria-hidden="true"
                          >
                            {initialsOf(row.student_name)}
                          </span>
                        )}
                        {profile?.id_card_url && (
                          <span className="absolute -bottom-0.5 -end-0.5 grid h-4.5 w-4.5 place-items-center rounded-full bg-primary text-white shadow">
                            <Camera className="h-2.5 w-2.5" />
                          </span>
                        )}
                      </button>

                      {/* الاسم + الإيميل الجامعي + الرقم */}
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-2 truncate text-sm font-extrabold text-foreground">
                          <span className="truncate">{row.student_name}</span>
                          {blocked && (
                            <span className="shrink-0 rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-extrabold text-rose-600 dark:text-rose-400">
                              محظور
                            </span>
                          )}
                        </p>
                        <p
                          className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-muted-foreground"
                          dir="ltr"
                          title={profile?.email ?? ""}
                        >
                          <Mail className="h-3 w-3 shrink-0" />
                          <span className="truncate">
                            {profile?.email ?? row.university_id}
                          </span>
                        </p>
                        <p
                          className="mt-0.5 text-[11px] font-bold tabular-nums text-muted-foreground/80"
                          dir="ltr"
                        >
                          {row.university_id}
                        </p>
                      </div>

                      {/* وقت التسجيل */}
                      <div className="flex shrink-0 flex-col items-end leading-tight">
                        <span className="text-sm font-black tabular-nums text-foreground">
                          {formatTime(row.created_at)}
                        </span>
                        <span className="text-[11px] text-muted-foreground">
                          {relativeTime(row.created_at, now)}
                        </span>
                      </div>
                    </div>

                    {/* الإحصائيات + أزرار الإنذار والبلوك */}
                    <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/12 px-2.5 py-1 text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400">
                        حضور
                        <span className="tabular-nums">{attended}</span>
                      </span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/12 px-2.5 py-1 text-[11px] font-extrabold text-rose-600 dark:text-rose-400">
                        غياب
                        <span className="tabular-nums">{absences}</span>
                      </span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/12 px-2.5 py-1 text-[11px] font-extrabold text-amber-600 dark:text-amber-400">
                        إنذار
                        <span className="tabular-nums">{warnings}</span>
                      </span>

                      <span className="flex-1" />

                      <button
                        type="button"
                        onClick={() => onWarn(row.student_id, row.student_name)}
                        disabled={busy}
                        className="inline-flex h-8 items-center gap-1 rounded-full bg-amber-500/12 px-2.5 text-[11px] font-extrabold text-amber-600 transition-colors hover:bg-amber-500/22 disabled:opacity-50 dark:text-amber-400"
                        title="تسجيل إنذار على هذا الطالب"
                      >
                        <AlertTriangle className="h-3.5 w-3.5" />
                        إنذار
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onToggleBlock(row.student_id, blocked)
                        }
                        disabled={busy}
                        className={`inline-flex h-8 items-center gap-1 rounded-full px-2.5 text-[11px] font-extrabold transition-colors disabled:opacity-50 ${
                          blocked
                            ? "bg-emerald-500/12 text-emerald-600 hover:bg-emerald-500/22 dark:text-emerald-400"
                            : "bg-rose-500/12 text-rose-600 hover:bg-rose-500/22 dark:text-rose-400"
                        }`}
                        title={
                          blocked
                            ? "فك الحظر — سيستطيع تسجيل الحضور مجدداً"
                            : "بلوك — لن يستطيع تسجيل الحضور في جلساتك (فصل من المادة)"
                        }
                      >
                        {blocked ? (
                          <>
                            <ShieldCheck className="h-3.5 w-3.5" />
                            فك الحظر
                          </>
                        ) : (
                          <>
                            <Ban className="h-3.5 w-3.5" />
                            بلوك
                          </>
                        )}
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>

      {/* نافذة ملف الطالب (صورة البطاقة + البيانات + الإحصائيات) */}
      <Dialog
        open={viewing !== null}
        onOpenChange={(open) => {
          if (!open) setViewing(null);
        }}
      >
        <DialogContent className="max-w-md">
          {viewing && (
            <>
              <DialogHeader>
                <DialogTitle>ملف الطالب</DialogTitle>
                <DialogDescription>
                  البيانات كما سجّلها الطالب عند إنشاء حسابه
                </DialogDescription>
              </DialogHeader>

              {viewing.id_card_url ? (
                <img
                  src={viewing.id_card_url}
                  alt={`صورة بطاقة ${viewing.full_name}`}
                  className="max-h-72 w-full rounded-xl object-contain ring-1 ring-border"
                />
              ) : (
                <div className="flex h-40 items-center justify-center rounded-xl bg-muted text-sm font-bold text-muted-foreground">
                  لا توجد صورة بطاقة مرفوعة
                </div>
              )}

              <div className="space-y-2 text-sm">
                <p className="font-extrabold text-foreground">
                  {viewing.full_name}
                </p>
                <p
                  className="flex items-center gap-2 text-muted-foreground"
                  dir="ltr"
                >
                  <Mail className="h-3.5 w-3.5 shrink-0" />
                  {viewing.email}
                </p>
                <p className="font-bold tabular-nums text-muted-foreground" dir="ltr">
                  {viewing.university_id}
                </p>
                {viewingStats && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <span className="rounded-full bg-emerald-500/12 px-2.5 py-1 text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400">
                      حضور {viewingStats.attended}
                    </span>
                    <span className="rounded-full bg-rose-500/12 px-2.5 py-1 text-[11px] font-extrabold text-rose-600 dark:text-rose-400">
                      غياب {viewingStats.absences}
                    </span>
                    <span className="rounded-full bg-amber-500/12 px-2.5 py-1 text-[11px] font-extrabold text-amber-600 dark:text-amber-400">
                      إنذار {viewingStats.warnings}
                    </span>
                    {viewingStats.blocked && (
                      <span className="rounded-full bg-rose-500/15 px-2.5 py-1 text-[11px] font-extrabold text-rose-600 dark:text-rose-400">
                        محظور
                      </span>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
