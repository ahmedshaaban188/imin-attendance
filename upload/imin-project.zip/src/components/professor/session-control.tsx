"use client";

/**
 * ============================================================================
 *  ImIn | لوحة الدكتور — بطاقة التحكم بالجلسة
 * ============================================================================
 *  الحالات الثلاث:
 *  1) لا جلسة بعد        → زر "فتح جلسة حضور جديدة" (يلتقط GPS تلقائياً)
 *  2) تحديد الموقع        → عرض الإحداثيات + منزلق النطاق (radius) + تأكيد البدء
 *  3) جلسة مفتوحة         → مؤقت مباشر + التفاصيل + زر إنهاء الجلسة (is_open=false)
 *  + حالة "آخر جلسة منتهية" مع ملخصها وزر بدء جلسة جديدة
 * ============================================================================
 */

import * as React from "react";
import {
  LocateFixed,
  Loader2,
  MapPin,
  Radius,
  Users,
  XCircle,
  Check,
  X,
  ExternalLink,
  Timer,
  Navigation,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { getCurrentPositionOnce, geoErrorMessage } from "@/lib/geo";
import { formatDurationClock, formatTime, relativeTime } from "@/lib/format";
import type { GeoPosition, SessionRow } from "@/lib/types";

const RADIUS_MIN = 10;
const RADIUS_MAX = 1000;
const RADIUS_PRESETS = [25, 50, 100, 200, 500];

export interface SessionControlProps {
  /** الجلسة المعروضة حالياً (مفتوحة أو آخر جلسة مغلقة) أو null */
  session: SessionRow | null;
  /** عدد الطلاب المسجّلين في الجلسة المعروضة */
  presentCount: number;
  /** true أثناء تنفيذ عملية إنشاء/إنهاء */
  busy: boolean;
  /** التوقيت الحالي (لتحديث المؤقت والحسابات النسبية) */
  now: number;
  /** إنشاء جلسة جديدة — ترجع true عند النجاح */
  onCreateSession: (
    coords: Pick<GeoPosition, "lat" | "lng" | "accuracy">,
    radius: number
  ) => Promise<boolean>;
  /** إنهاء الجلسة المفتوحة */
  onCloseSession: () => Promise<void>;
}

export function SessionControl({
  session,
  presentCount,
  busy,
  now,
  onCreateSession,
  onCloseSession,
}: SessionControlProps) {
  const [locating, setLocating] = React.useState(false);
  const [draft, setDraft] = React.useState<GeoPosition | null>(null);
  const [radius, setRadius] = React.useState(50);
  const [radiusInput, setRadiusInput] = React.useState("50");
  const [confirmingClose, setConfirmingClose] = React.useState(false);
  const [creating, setCreating] = React.useState(false);

  const sessionOpen = Boolean(session?.is_open);

  /** تحديث النطاق من أي مصدر (المنزلق / الأرقام / الأزرار السريعة) */
  function applyRadius(value: number) {
    const clamped = Math.min(RADIUS_MAX, Math.max(RADIUS_MIN, value));
    setRadius(clamped);
    setRadiusInput(String(clamped));
  }

  /* ---------------------- بدء تحديد الموقع (GPS) ---------------------- */

  async function startLocating() {
    setLocating(true);
    setConfirmingClose(false);
    try {
      const position = await getCurrentPositionOnce();
      setDraft(position);
      toast.success("تم تحديد موقعك الحالي بنجاح — اضبط النطاق ثم أكّد بدء الجلسة");
    } catch (error) {
      toast.error(geoErrorMessage(error));
    } finally {
      setLocating(false);
    }
  }

  /* ------------------------- تأكيد بدء الجلسة ------------------------- */

  async function confirmSession() {
    if (!draft) return;
    setCreating(true);
    const created = await onCreateSession(
      { lat: draft.lat, lng: draft.lng, accuracy: draft.accuracy },
      radius
    );
    setCreating(false);
    if (created) {
      setDraft(null);
      applyRadius(50);
    }
  }

  /* ------------------------------ العرض ------------------------------ */

  return (
    <section className="glass-card p-5 sm:p-6" aria-label="التحكم بجلسة الحضور">
      <header className="flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-2.5 text-lg font-black">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/12 text-primary">
            <Navigation className="h-5 w-5" />
          </span>
          التحكم بالجلسة
        </h2>
        {session && (
          <span
            className={`rounded-full px-3 py-1 text-xs font-extrabold ${
              sessionOpen
                ? "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {sessionOpen ? "مفتوحة الآن" : "منتهية"}
          </span>
        )}
      </header>

      {/* شريط العدّاد اللحظي: عدد الحاضرين أثناء المحاضرة أو "لا جلسة مفتوحة" */}
      <div
        className={`mt-4 flex items-center justify-between gap-3 rounded-2xl border px-4 py-3 transition-colors ${
          sessionOpen
            ? "border-primary/25 bg-primary/8"
            : "border-border bg-muted/30"
        }`}
        aria-live="polite"
      >
        {sessionOpen ? (
          <>
            <p className="flex items-center gap-2 text-sm font-extrabold text-primary">
              <Users className="h-4.5 w-4.5" />
              طالب حاضر بآخر جلسة
            </p>
            <p className="text-2xl font-black leading-none tabular-nums text-primary">
              {presentCount}
            </p>
          </>
        ) : (
          <p className="w-full text-center text-sm font-extrabold text-muted-foreground">
            لا جلسة مفتوحة
          </p>
        )}
      </div>

      {/* ============ (1) جلسة مفتوحة حالياً ============ */}
      {sessionOpen && session ? (
        <div className="mt-5">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-emerald-500/8 border border-emerald-500/25 px-4 py-3.5">
            <p className="flex items-center gap-2.5 text-sm font-extrabold text-emerald-700 dark:text-emerald-300">
              <span className="live-dot" />
              الجلسة مفتوحة — الطلاب داخل النطاق يسجّلون حضورهم الآن
            </p>
            <p className="text-xs text-muted-foreground">
              فُتحت {formatTime(session.created_at)} ({relativeTime(session.created_at, now)})
            </p>
          </div>

          {/* المؤقت المباشر */}
          <div className="mt-5 grid gap-4">
            <div className="rounded-2xl bg-white/45 dark:bg-white/5 border border-border p-5 flex flex-col items-center justify-center">
              <p className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
                <Timer className="h-3.5 w-3.5" />
                مدة الجلسة حتى الآن
              </p>
              <p
                dir="ltr"
                className="mt-2 text-4xl font-black tabular-nums tracking-tight text-foreground"
              >
                {formatDurationClock(now - new Date(session.created_at).getTime())}
              </p>
            </div>

            <div className="rounded-2xl bg-white/45 dark:bg-white/5 border border-border p-5 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 font-bold text-muted-foreground">
                  <Users className="h-4 w-4 text-primary" />
                  المسجّلون
                </span>
                <span className="text-lg font-black text-primary tabular-nums">
                  {presentCount}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 font-bold text-muted-foreground">
                  <Radius className="h-4 w-4 text-primary" />
                  النطاق المسموح
                </span>
                <span className="font-extrabold tabular-nums" dir="ltr">
                  {session.radius} م
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 font-bold text-muted-foreground">
                  <MapPin className="h-4 w-4 text-primary" />
                  إحداثيات القاعة
                </span>
                <span className="font-mono text-xs font-extrabold tabular-nums" dir="ltr">
                  {Number(session.lat).toFixed(5)}, {Number(session.lng).toFixed(5)}
                </span>
              </div>
              <a
                href={`https://www.google.com/maps?q=${Number(session.lat)},${Number(session.lng)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 rounded-xl bg-primary/10 py-2 text-xs font-bold text-primary transition-colors hover:bg-primary/20"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                عرض موقع الجلسة على الخريطة
              </a>
            </div>
          </div>

          {/* إنهاء الجلسة */}
          <div className="mt-5">
            {confirmingClose ? (
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                <p className="flex-1 rounded-xl bg-destructive/10 px-4 py-2.5 text-sm font-bold text-destructive">
                  هل تريد إنهاء الجلسة الآن؟ لن يستطيع الطلاب تسجيل الحضور بعدها.
                </p>
                <Button
                  onClick={async () => {
                    await onCloseSession();
                    setConfirmingClose(false);
                  }}
                  disabled={busy}
                  className="h-11 rounded-xl bg-destructive text-white hover:bg-destructive/90 font-bold"
                >
                  {busy ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <Check className="h-4.5 w-4.5" />}
                  نعم، أنهِ الجلسة
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setConfirmingClose(false)}
                  disabled={busy}
                  className="h-11 rounded-xl font-bold"
                >
                  <X className="h-4.5 w-4.5" />
                  إلغاء
                </Button>
              </div>
            ) : (
              <Button
                onClick={() => setConfirmingClose(true)}
                disabled={busy}
                variant="outline"
                className="h-12 w-full rounded-2xl border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive font-extrabold"
              >
                <XCircle className="h-5 w-5" />
                إنهاء الجلسة الحالية
              </Button>
            )}
          </div>
        </div>
      ) : draft ? (
        /* ============ (2) تم تحديد الموقع — ضبط النطاق وتأكيد البدء ============ */
        <div className="mt-5">
          <div className="rounded-2xl bg-primary/8 border border-primary/25 px-4 py-3.5 flex flex-wrap items-center justify-between gap-2">
            <p className="flex items-center gap-2 text-sm font-extrabold text-primary">
              <MapPin className="h-4.5 w-4.5" />
              تم تحديد موقعك الحالي
            </p>
            <p className="font-mono text-xs font-bold tabular-nums" dir="ltr">
              {draft.lat.toFixed(5)}, {draft.lng.toFixed(5)}
            </p>
            <span className="rounded-full bg-primary/12 px-2.5 py-1 text-[11px] font-bold text-primary">
              الدقة ±{Math.round(draft.accuracy)} م
            </span>
          </div>

          {/* إدخال عدد الأمتار + المنزلق */}
          <div className="mt-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label htmlFor="session-radius" className="text-sm font-bold text-foreground">
                النطاق المسموح به (عدد الأمتار)
              </label>
              <div className="flex items-center gap-2">
                <Input
                  id="session-radius"
                  type="number"
                  dir="ltr"
                  inputMode="numeric"
                  min={RADIUS_MIN}
                  max={RADIUS_MAX}
                  step={5}
                  value={radiusInput}
                  onChange={(event) => {
                    const raw = event.target.value;
                    setRadiusInput(raw);
                    const parsed = Number.parseInt(raw, 10);
                    if (Number.isFinite(parsed)) {
                      setRadius(Math.min(RADIUS_MAX, Math.max(RADIUS_MIN, parsed)));
                    }
                  }}
                  onBlur={() => setRadiusInput(String(radius))}
                  disabled={creating}
                  className="input-glass h-10 w-28 text-center text-sm font-black tabular-nums"
                  aria-label="عدد الأمتار المسموح بها للتسجيل"
                />
                <span className="text-sm font-bold text-muted-foreground">متر</span>
              </div>
            </div>
            <Slider
              id="session-radius-slider"
              value={[radius]}
              onValueChange={(values) => applyRadius(values[0])}
              min={RADIUS_MIN}
              max={RADIUS_MAX}
              step={5}
              disabled={creating}
              className="mt-4"
              aria-label="تحديد نطاق الجلسة بالأمتار"
            />
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {RADIUS_PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => applyRadius(preset)}
                  disabled={creating}
                  className={`glass-chip rounded-full px-3.5 py-1.5 text-xs font-extrabold tabular-nums transition-all ${
                    radius === preset ? "text-primary ring-2 ring-primary/40" : "text-muted-foreground hover:text-foreground"
                  }`}
                  dir="ltr"
                >
                  {preset} م
                </button>
              ))}
              <span className="text-[11px] text-muted-foreground">
                اكتب عدد الأمتار مباشرة أو اختر قيمة سريعة — من {RADIUS_MIN} إلى {RADIUS_MAX} متر
              </span>
            </div>
          </div>

          <div className="mt-6 grid gap-2.5 sm:grid-cols-2">
            <Button
              onClick={confirmSession}
              disabled={creating}
              className="btn-gradient h-12 rounded-2xl text-base font-extrabold"
            >
              {creating ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  <Check className="h-5 w-5" />
                  تأكيد بدء الجلسة
                </>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => setDraft(null)}
              disabled={creating}
              className="h-12 rounded-2xl font-bold"
            >
              <X className="h-5 w-5" />
              إلغاء وتحديد الموقع مجدداً
            </Button>
          </div>
        </div>
      ) : (
        /* ============ (3) لا جلسة مفتوحة — دعوة لبدء جلسة ============ */
        <div className="mt-5">
          {/* ملخص آخر جلسة إن وُجدت */}
          {session && !sessionOpen && (
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border bg-white/40 dark:bg-white/5 px-4 py-3">
              <p className="text-sm text-muted-foreground">
                آخر جلسة لك انتهت{" "}
                <span className="font-bold text-foreground">
                  {relativeTime(session.created_at, now)}
                </span>{" "}
                ووثّقت حضور{" "}
                <span className="font-black text-primary tabular-nums">{presentCount}</span> طالباً.
              </p>
            </div>
          )}

          <div className="rounded-2xl border-2 border-dashed border-primary/30 bg-primary/5 px-5 py-8 text-center">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-primary/12 text-primary animate-float-y">
              <LocateFixed className="h-8 w-8" />
            </span>
            <h3 className="mt-4 text-lg font-black">فتح جلسة حضور جديدة</h3>
            <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
              سيتم التقاط موقعك الحالي تلقائياً عبر GPS لتوثيق إحداثيات القاعة، ثم تحدد النطاق
              المسموح بالأمتار — ولن يستطيع الطلاب تسجيل الحضور إلا من داخله.
            </p>
            <Button
              onClick={startLocating}
              disabled={locating}
              className="btn-gradient mt-5 h-12 rounded-2xl px-6 text-base font-extrabold"
            >
              {locating ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  جارٍ التقاط موقعك الحالي...
                </>
              ) : (
                <>
                  <LocateFixed className="h-5 w-5" />
                  تحديد موقعي وبدء الجلسة
                </>
              )}
            </Button>
          </div>
        </div>
      )}
    </section>
  );
}
