"use client";

/**
 * ============================================================================
 *  ImIn | لوحة تحكم الدكتور (مكافئ professor-dashboard.html)
 * ============================================================================
 *  - فتح جلسة محاضرة جديدة: التقاط موقع GPS تلقائياً + تحديد نطاق الأمتار (radius)
 *    وتفعيل is_open = true
 *  - عرض الحضور الفوري واللحظي (Real-time) للطلاب المسجّلين في الجلسة الحالية
 *    من جدول attendance عبر Supabase Realtime
 *  - إنهاء الجلسة (is_open = false) مع الاحتفاظ بملخص آخر جلسة
 *  - استعادة آخر جلسة عند إعادة تحميل الصفحة دون فقدان البيانات
 * ============================================================================
 */

import * as React from "react";
import { toast } from "sonner";
import { Users, Radio, Radius } from "lucide-react";
import { AppHeader } from "@/components/app-header";
import { DemoBadge } from "@/components/demo-badge";
import { SessionControl } from "@/components/professor/session-control";
import { LiveAttendance } from "@/components/professor/live-attendance";
import {
  fetchProfessorSessions,
  fetchAttendance,
  createSession,
  closeSession,
  subscribeAttendanceUpdates,
  fetchProfessorStats,
  fetchStudentProfiles,
  blockStudent,
  unblockStudent,
  warnStudent,
} from "@/lib/data-layer";
import { friendlyError } from "@/lib/supabaseClient";
import { formatDate, greetingForNow } from "@/lib/format";
import type {
  AppUser,
  AttendanceRow,
  ProfessorRosterStats,
  RealtimeStatus,
  SessionRow,
} from "@/lib/types";

export function ProfessorView({
  user,
  onLogout,
}: {
  user: AppUser;
  onLogout: () => void;
}) {
  const [session, setSession] = React.useState<SessionRow | null>(null);
  const [attendance, setAttendance] = React.useState<AttendanceRow[]>([]);
  const [realtimeStatus, setRealtimeStatus] = React.useState<RealtimeStatus>("closed");
  const [loading, setLoading] = React.useState(true);
  const [busy, setBusy] = React.useState(false);
  const [now, setNow] = React.useState(() => Date.now());

  /* إحصائيات الطلاب (حضور/غياب/إنذارات/محظورون) وملفاتهم */
  const [stats, setStats] = React.useState<ProfessorRosterStats | null>(null);
  const [profilesById, setProfilesById] = React.useState<Record<string, AppUser>>({});
  const [actionBusyStudentId, setActionBusyStudentId] = React.useState<string | null>(null);

  const sessionOpen = Boolean(session?.is_open);

  /* مرآة ref لقائمة الحضور — تقرأها refreshRoster دون الاعتماد عليها */
  const attendanceRef = React.useRef<AttendanceRow[]>([]);
  React.useEffect(() => {
    attendanceRef.current = attendance;
  }, [attendance]);

  /* ------------------------------------------------------------------ */
  /*  عدّاد الزمن: كل ثانية أثناء الجلسة المفتوحة (للمؤقت) وكل 30 ثانية  */
  /*  فيما عدا ذلك (لتحديث الأزمنة النسبية)                              */
  /* ------------------------------------------------------------------ */
  React.useEffect(() => {
    const interval = sessionOpen ? 1000 : 30000;
    const id = window.setInterval(() => setNow(Date.now()), interval);
    return () => window.clearInterval(id);
  }, [sessionOpen]);

  /* ------------------------------------------------------------------ */
  /*  تحميل آخر جلسة (المفتوحة أولاً) + حضورها عند فتح اللوحة             */
  /* ------------------------------------------------------------------ */
  const loadDashboard = React.useCallback(async () => {
    setLoading(true);
    try {
      const { open, lastClosed } = await fetchProfessorSessions(user.id);

      if (open) {
        setSession(open);
        await loadAttendanceFor(open.id);
        return;
      }

      if (lastClosed) {
        setSession(lastClosed);
        await loadAttendanceFor(lastClosed.id);
      } else {
        setSession(null);
        setAttendance([]);
      }
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setLoading(false);
    }
  }, [user.id]);

  React.useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  async function loadAttendanceFor(sessionId: string) {
    try {
      const rows = await fetchAttendance(sessionId);
      setAttendance(rows);
    } catch (error) {
      toast.error(friendlyError(error));
    }
  }

  /* ------------------------------------------------------------------ */
  /*  إحصائيات وملفات الطلاب (حضور/غياب/إنذارات/محظورون)                  */
  /*  تُحدَّث عند الفتح + كلما تغيّر عدد الحاضرين (تسجيل حضور جديد)          */
  /* ------------------------------------------------------------------ */
  const refreshRoster = React.useCallback(async () => {
    try {
      const statsData = await fetchProfessorStats(user.id);
      setStats(statsData);

      const ids = new Set<string>([
        ...attendanceRef.current.map((row) => row.student_id),
        ...statsData.blockedIds,
      ]);
      if (ids.size > 0) {
        const profiles = await fetchStudentProfiles([...ids]);
        setProfilesById(
          Object.fromEntries(profiles.map((profile) => [profile.id, profile]))
        );
      } else {
        setProfilesById({});
      }
    } catch (error) {
      toast.error(friendlyError(error));
    }
  }, [user.id]);

  const attendanceCount = attendance.length;
  React.useEffect(() => {
    void refreshRoster();
  }, [refreshRoster, attendanceCount]);

  /* ------------------------------------------------------------------ */
  /*  الاشتراك اللحظي (Realtime) في تسجيلات الحضور للجلسة المفتوحة        */
  /*  (Supabase Realtime أو استقصاء دوري في الوضع التجريبي)              */
  /* ------------------------------------------------------------------ */
  React.useEffect(() => {
    if (!session?.id || !session.is_open) {
      setRealtimeStatus("closed");
      return;
    }

    const unsubscribe = subscribeAttendanceUpdates(session.id, {
      onRows: (rows) => setAttendance(rows),
      onAppend: (newRow) => {
        setAttendance((previous) =>
          previous.some((row) => row.id === newRow.id) ? previous : [newRow, ...previous]
        );
      },
      onStatus: (status) => setRealtimeStatus(status),
    });

    return unsubscribe;
  }, [session?.id, session?.is_open]);

  /* ------------------------------------------------------------------ */
  /*  إنشاء جلسة جديدة (is_open = true)                                   */
  /* ------------------------------------------------------------------ */
  async function handleCreateSession(
    coords: { lat: number; lng: number; accuracy: number },
    radius: number
  ): Promise<boolean> {
    setBusy(true);
    try {
      const created = await createSession({
        professor_id: user.id,
        lat: coords.lat,
        lng: coords.lng,
        radius,
      });

      setSession(created);
      setAttendance([]);
      toast.success(
        "تم فتح الجلسة بنجاح — الطلاب داخل نطاق " + radius + " متراً يمكنهم تسجيل الحضور الآن"
      );
      return true;
    } catch (error) {
      toast.error(friendlyError(error));
      return false;
    } finally {
      setBusy(false);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  إنهاء الجلسة (is_open = false)                                      */
  /* ------------------------------------------------------------------ */
  async function handleCloseSession() {
    if (!session) return;
    setBusy(true);
    try {
      await closeSession(session.id);

      setSession({ ...session, is_open: false });
      toast.success(`تم إنهاء الجلسة — توثّق حضور ${attendance.length} طالباً ويمكن تصديره CSV`);
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setBusy(false);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  حظر طالب / فك الحظر (فصل من المادة)                                 */
  /* ------------------------------------------------------------------ */
  async function handleToggleBlock(studentId: string, currentlyBlocked: boolean) {
    setActionBusyStudentId(studentId);
    try {
      if (currentlyBlocked) {
        await unblockStudent(user.id, studentId);
        toast.success("تم فك الحظر — سيستطيع الطالب تسجيل حضوره مجدداً");
      } else {
        await blockStudent(user.id, studentId);
        toast.success(
          "تم حظر الطالب (فصله من المادة) — لن يستطيع تسجيل الحضور في جلساتك القادمة"
        );
      }
      await refreshRoster();
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setActionBusyStudentId(null);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  تسجيل إنذار على طالب                                                */
  /* ------------------------------------------------------------------ */
  async function handleWarn(studentId: string, studentName: string) {
    if (!window.confirm(`تسجيل إنذار جديد على الطالب "${studentName}"؟`)) return;
    setActionBusyStudentId(studentId);
    try {
      await warnStudent(user.id, studentId);
      toast.success(`تم تسجيل إنذار على ${studentName}`);
      await refreshRoster();
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setActionBusyStudentId(null);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  العرض                                                               */
  /* ------------------------------------------------------------------ */

  return (
    <main className="relative flex min-h-screen flex-col">
      {/* الخلفية الزجاجية المتوهجة */}
      <div className="orbs" aria-hidden="true">
        <span className="orb orb-1" />
        <span className="orb orb-2" />
        <span className="orb orb-3" />
      </div>

      <AppHeader user={user} badge="لوحة الدكتور" onLogout={onLogout} extra={<DemoBadge />} />

      <div className="relative z-10 mx-auto w-full max-w-6xl flex-1 space-y-5 px-4 py-6 sm:px-6">
        {/* الترحيب */}
        <section className="flex flex-wrap items-end justify-between gap-2 px-1">
          <div>
            <h1 className="text-2xl font-black text-foreground sm:text-[1.7rem]">
              {greetingForNow()} د. {user.full_name.split(" ")[0]}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">{formatDate(new Date().toISOString())}</p>
          </div>
          <p className="text-xs font-bold text-muted-foreground" dir="ltr">
            {user.email}
          </p>
        </section>

        {/* بطاقات الإحصائيات */}
        <section className="grid grid-cols-3 gap-3 sm:gap-4" aria-label="إحصائيات الجلسة">
          <div className="glass-card flex items-center gap-3 p-4">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary/12 text-primary">
              <Users className="h-5.5 w-5.5" />
            </span>
            <div className="min-w-0">
              <p className="text-2xl font-black tabular-nums text-foreground leading-none">
                {loading ? "—" : attendance.length}
              </p>
              <p className="mt-1 truncate text-xs font-bold text-muted-foreground">
                طالب حاضر بآخر جلسة
              </p>
            </div>
          </div>

          <div className="glass-card flex items-center gap-3 p-4">
            <span
              className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${
                sessionOpen
                  ? "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              <Radio className="h-5.5 w-5.5" />
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-black text-foreground leading-none">
                {sessionOpen ? (realtimeStatus === "live" ? "بث مباشر" : "جارٍ الاتصال") : "لا جلسة مفتوحة"}
              </p>
              <p className="mt-1 truncate text-xs font-bold text-muted-foreground">
                حالة قائمة الحضور
              </p>
            </div>
          </div>

          <div className="glass-card flex items-center gap-3 p-4">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-amber-500/12 text-amber-600 dark:text-amber-400">
              <Radius className="h-5.5 w-5.5" />
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-black tabular-nums text-foreground leading-none" dir="ltr">
                {session ? `${session.radius} م` : "—"}
              </p>
              <p className="mt-1 truncate text-xs font-bold text-muted-foreground">نطاق الجلسة</p>
            </div>
          </div>
        </section>

        {/* الشبكة الرئيسية: التحكم بالجلسة + قائمة الحضور بالبيانات الكاملة */}
        <div className="grid items-start gap-4 sm:gap-6 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <SessionControl
              session={session}
              presentCount={attendance.length}
              busy={busy}
              now={now}
              onCreateSession={handleCreateSession}
              onCloseSession={handleCloseSession}
            />
          </div>
          <div className="lg:col-span-3">
            <LiveAttendance
              attendance={attendance}
              status={realtimeStatus}
              loading={loading}
              isLiveSession={sessionOpen}
              now={now}
              profilesById={profilesById}
              stats={stats}
              onToggleBlock={handleToggleBlock}
              onWarn={handleWarn}
              actionBusyStudentId={actionBusyStudentId}
            />
          </div>
        </div>
      </div>

      {/* تذييل */}
      <footer className="relative z-10 py-5 text-center text-xs text-muted-foreground">
        ImIn — لوحة الدكتور
      </footer>
    </main>
  );
}
