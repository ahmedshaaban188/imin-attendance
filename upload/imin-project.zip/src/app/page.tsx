"use client";

/**
 * ============================================================================
 *  ImIn | الصفحة الرئيسية — موزّع الواجهات الثلاث
 * ============================================================================
 *  تعمل هذه الصفحة كنقطة الدخول الوحيدة للنظام وتتنقّل بين الواجهات الثلاث
 *  حسب حالة المستخدم المسجّلة في localStorage (imin-user):
 *
 *    1) AuthView        (مكافئ index.html)            → الدخول والتسجيل
 *    2) ProfessorView   (مكافئ professor-dashboard.html) → لوحة الدكتور
 *    3) StudentView     (مكافئ student-dashboard.html)   → لوحة الطالب
 *
 *  ملاحظة معمارية: وفق قيود بيئة المعاينة هذه، لا يستطيع المستخدم رؤية سوى
 *  مسار "/" لذلك تتم إدارة "الصفحات" داخل هذه الصفحة الواحدة بدلاً من
 *  التوجيه إلى مسارات متعددة — والنتيجة النهائية مطابقة تماماً.
 * ============================================================================
 */

import * as React from "react";
import { Loader2 } from "lucide-react";
import { AuthView } from "@/components/auth/auth-view";
import { ProfessorView } from "@/components/professor/professor-view";
import { StudentView } from "@/components/student/student-view";
import { clearUserFromLocalStorage, getUserFromLocalStorage } from "@/lib/supabaseClient";
import type { AppUser } from "@/lib/types";

type ActiveView = "loading" | "auth" | "professor" | "student";

export default function HomePage() {
  const [view, setView] = React.useState<ActiveView>("loading");
  const [user, setUser] = React.useState<AppUser | null>(null);

  /* قراءة المستخدم الحالي من localStorage عند تحميل الصفحة */
  React.useEffect(() => {
    const storedUser = getUserFromLocalStorage();
    if (storedUser) {
      setUser(storedUser);
      setView(storedUser.role === "professor" ? "professor" : "student");
    } else {
      setView("auth");
    }
  }, []);

  /* بعد تسجيل الدخول أو إنشاء حساب جديد بنجاح */
  function handleAuthSuccess(authenticatedUser: AppUser) {
    setUser(authenticatedUser);
    setView(authenticatedUser.role === "professor" ? "professor" : "student");
  }

  /* تسجيل الخروج */
  function handleLogout() {
    clearUserFromLocalStorage();
    setUser(null);
    setView("auth");
  }

  /* شاشة التحميل الأولية أثناء قراءة الجلسة */
  if (view === "loading" || (view !== "auth" && !user)) {
    return (
      <main className="relative flex min-h-screen items-center justify-center">
        <div className="orbs" aria-hidden="true">
          <span className="orb orb-1" />
          <span className="orb orb-2" />
          <span className="orb orb-3" />
        </div>
        <div className="glass-card flex flex-col items-center gap-4 px-10 py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm font-bold text-muted-foreground">جارٍ تحضير لوحتك...</p>
        </div>
      </main>
    );
  }

  if (view === "professor" && user) {
    return <ProfessorView user={user} onLogout={handleLogout} />;
  }

  if (view === "student" && user) {
    return <StudentView user={user} onLogout={handleLogout} />;
  }

  return <AuthView onSuccess={handleAuthSuccess} />;
}
