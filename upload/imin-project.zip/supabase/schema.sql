-- ============================================================================
--  ImIn | نظام الحضور الجامعي الذكي — ملف إعداد قاعدة بيانات Supabase
-- ============================================================================
--
--  خطوات التشغيل (دقيقتان):
--  1) أنشئ مشروعاً مجانياً على https://supabase.com
--  2) افتح:  SQL Editor  ->  New query
--  3) الصق هذا الملف كاملاً واضغط  RUN
--  4) من: Project Settings -> API  انسخ  Project URL  و  anon public key
--     وضعهما في ملف src/lib/supabaseClient.js داخل مشروع Next.js
--
--  هذا الملف "آمن للتشغيل المتكرر" (idempotent) — لن يكرر الجداول أو السياسات.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- (1) الإضافة المطلوبة لتوليد UUID تلقائياً
-- ----------------------------------------------------------------------------
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- (2) جدول المستخدمين (users)
-- ----------------------------------------------------------------------------
create table if not exists public.users (
  id            uuid primary key default gen_random_uuid(),
  full_name     text not null,
  email         text unique not null,
  university_id text not null,
  role          text not null check (role in ('student', 'professor')),
  id_card_url   text,
  created_at    timestamptz not null default now()
);

comment on table public.users is 'ImIn: مستخدمو النظام (طلاب ودكاترة)';

-- ----------------------------------------------------------------------------
-- (3) جدول الجلسات (sessions)
-- ----------------------------------------------------------------------------
create table if not exists public.sessions (
  id           uuid primary key default gen_random_uuid(),
  professor_id uuid not null references public.users (id) on delete cascade,
  lat          numeric not null,
  lng          numeric not null,
  radius       integer not null default 50,
  is_open      boolean not null default true,
  created_at   timestamptz not null default now()
);

comment on table public.sessions is 'ImIn: جلسات الحضور التي يفتحها الدكاترة بإحداثيات GPS';

-- ----------------------------------------------------------------------------
-- (4) جدول الحضور (attendance)
-- ----------------------------------------------------------------------------
create table if not exists public.attendance (
  id            uuid primary key default gen_random_uuid(),
  session_id    uuid not null references public.sessions (id) on delete cascade,
  student_id    uuid not null references public.users (id) on delete cascade,
  student_name  text not null,
  university_id text not null,
  created_at    timestamptz not null default now()
);

comment on table public.attendance is 'ImIn: سجلات حضور الطلاب في الجلسات';

-- قيد فريد: لا يمكن للطالب تسجيل حضوره مرتين في نفس الجلسة
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'attendance_session_student_unique'
  ) then
    alter table public.attendance
      add constraint attendance_session_student_unique unique (session_id, student_id);
  end if;
end $$;

-- ----------------------------------------------------------------------------
-- (5) فهارس لتسريع الاستعلامات
-- ----------------------------------------------------------------------------
create index if not exists idx_sessions_professor on public.sessions (professor_id);
create index if not exists idx_sessions_open      on public.sessions (is_open);
create index if not exists idx_attendance_session on public.attendance (session_id);
create index if not exists idx_attendance_student on public.attendance (student_id);
create index if not exists idx_users_university_id on public.users (university_id);

-- ----------------------------------------------------------------------------
-- (6) تفعيل البث اللحظي (Realtime) على جدولي attendance و sessions
--     - attendance: ليظهر الحضور أمام الدكتور لحظة بلحظة
--     - sessions : ليكشف الطلاب فتح/إنهاء الجلسات فوراً
-- ----------------------------------------------------------------------------
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'attendance'
  ) then
    alter publication supabase_realtime add table public.attendance;
  end if;

  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'sessions'
  ) then
    alter publication supabase_realtime add table public.sessions;
  end if;
end $$;

-- هوية النسخ الكاملة لضمان عمل أحداث UPDATE مع Realtime
alter table public.attendance replica identity full;
alter table public.sessions    replica identity full;

-- ----------------------------------------------------------------------------
-- (7) أمان صفوف Row Level Security (RLS)
--
--  ملاحظة أمنية مهمة:
--  السياسات أدناه "متساهلة" لأن هذا النموذج يعتمد على anon key مباشرة من
--  المتصفح بدون كلمات مرور (حسب المخطط المطلوب). في بيئة إنتاج حقيقية
--  يُنصح بشدة باستخدام Supabase Auth وتقييد السياسات بـ auth.uid().
-- ----------------------------------------------------------------------------
alter table public.users      enable row level security;
alter table public.sessions   enable row level security;
alter table public.attendance enable row level security;

-- users: قراءة (لتسجيل الدخول) + إدراج (لإنشاء الحسابات)
drop policy if exists "imin_users_select" on public.users;
create policy "imin_users_select" on public.users
  for select using (true);

drop policy if exists "imin_users_insert" on public.users;
create policy "imin_users_insert" on public.users
  for insert with check (true);

-- sessions: قراءة (لكشف الجلسات المفتوحة) + إدراج (لفتح جلسة) + تعديل (للإنهاء)
drop policy if exists "imin_sessions_select" on public.sessions;
create policy "imin_sessions_select" on public.sessions
  for select using (true);

drop policy if exists "imin_sessions_insert" on public.sessions;
create policy "imin_sessions_insert" on public.sessions
  for insert with check (true);

drop policy if exists "imin_sessions_update" on public.sessions;
create policy "imin_sessions_update" on public.sessions
  for update using (true) with check (true);

-- attendance: قراءة (للوحات الحضور) + إدراج (لتسجيل الحضور)
drop policy if exists "imin_attendance_select" on public.attendance;
create policy "imin_attendance_select" on public.attendance
  for select using (true);

drop policy if exists "imin_attendance_insert" on public.attendance;
create policy "imin_attendance_insert" on public.attendance
  for insert with check (true);

-- ----------------------------------------------------------------------------
-- (8) جدول الطلاب المحظورين (blocked_students) — حظر/فصل الطالب من محاضرات الدكتور
-- ----------------------------------------------------------------------------
create table if not exists public.blocked_students (
  id           uuid primary key default gen_random_uuid(),
  professor_id uuid not null references public.users (id) on delete cascade,
  student_id   uuid not null references public.users (id) on delete cascade,
  created_at   timestamptz not null default now(),
  unique (professor_id, student_id)
);

comment on table public.blocked_students is 'ImIn: الطلاب المحظورون/المفصولون من محاضرات الدكتور (ممنوعون من تسجيل الحضور)';

create index if not exists idx_blocked_professor on public.blocked_students (professor_id);
create index if not exists idx_blocked_student   on public.blocked_students (student_id);

-- ----------------------------------------------------------------------------
-- (9) جدول الإنذارات (warnings) — إنذارات الطلاب من الدكتور
-- ----------------------------------------------------------------------------
create table if not exists public.warnings (
  id           uuid primary key default gen_random_uuid(),
  professor_id uuid not null references public.users (id) on delete cascade,
  student_id   uuid not null references public.users (id) on delete cascade,
  reason       text,
  created_at   timestamptz not null default now()
);

comment on table public.warnings is 'ImIn: إنذارات الطلاب المسجّلة من قبل الدكاترة';

create index if not exists idx_warnings_professor on public.warnings (professor_id);
create index if not exists idx_warnings_student   on public.warnings (student_id);

-- ----------------------------------------------------------------------------
-- (10) منع الطلاب المحظورين من تسجيل الحضور (على مستوى قاعدة البيانات نفسها)
--      يمنع أي إدراج حضور لطالب محظور لدى صاحب الجلسة حتى لو جاء الطلب من خارج الواجهة
-- ----------------------------------------------------------------------------
create or replace function public.imin_block_check() returns trigger as $$
begin
  if exists (
    select 1
    from public.blocked_students b
    join public.sessions s on s.id = new.session_id
    where b.student_id = new.student_id
      and b.professor_id = s.professor_id
  ) then
    raise exception 'أنت محظور من حضور محاضرات هذا الدكتور.';
  end if;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists imin_attendance_block_trigger on public.attendance;
create trigger imin_attendance_block_trigger
  before insert on public.attendance
  for each row execute function public.imin_block_check();

-- ----------------------------------------------------------------------------
-- (11) أمان RLS للجدولين الجديدين (نفس أسلوب باقي الجداول في هذا النموذج)
-- ----------------------------------------------------------------------------
alter table public.blocked_students enable row level security;
alter table public.warnings      enable row level security;

drop policy if exists "imin_blocked_select" on public.blocked_students;
create policy "imin_blocked_select" on public.blocked_students
  for select using (true);

drop policy if exists "imin_blocked_insert" on public.blocked_students;
create policy "imin_blocked_insert" on public.blocked_students
  for insert with check (true);

drop policy if exists "imin_blocked_delete" on public.blocked_students;
create policy "imin_blocked_delete" on public.blocked_students
  for delete using (true);

drop policy if exists "imin_warnings_select" on public.warnings;
create policy "imin_warnings_select" on public.warnings
  for select using (true);

drop policy if exists "imin_warnings_insert" on public.warnings;
create policy "imin_warnings_insert" on public.warnings
  for insert with check (true);

-- ----------------------------------------------------------------------------
-- (12) مخزن الملفات (Storage): bucket عام لصور بطاقات الهوية
-- ----------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('id-cards', 'id-cards', true)
on conflict (id) do nothing;

-- السماح بقراءة روابط الصور العامة
drop policy if exists "imin_idcards_read" on storage.objects;
create policy "imin_idcards_read" on storage.objects
  for select using (bucket_id = 'id-cards');

-- السماح برفع صور البطاقات من صفحة التسجيل
drop policy if exists "imin_idcards_upload" on storage.objects;
create policy "imin_idcards_upload" on storage.objects
  for insert with check (bucket_id = 'id-cards');

-- ----------------------------------------------------------------------------
-- تم! قاعدة البيانات جاهزة بالكامل.
-- ----------------------------------------------------------------------------
